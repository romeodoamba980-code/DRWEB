@echo off
chcp 65001 >nul
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
set "SRC=%~dp0source"
set "PSDIR="
for %%V in (2026 2025 2024 2023) do (
  if not defined PSDIR if exist "%ProgramFiles%\Adobe\Adobe Photoshop %%V\Photoshop.exe" set "PSDIR=%ProgramFiles%\Adobe\Adobe Photoshop %%V"
)
if not defined PSDIR (
  echo Photoshop introuvable dans "%ProgramFiles%\Adobe".
  pause
  exit /b
)
echo Installation de Affiche Minute dans : %PSDIR%
xcopy "%SRC%" "%PSDIR%\Plug-ins\Affiche Minute\" /E /I /Y /Q

rem Nettoyage de l'ancienne tentative d'installation
set "UXP=%CommonProgramFiles%\Adobe\UXP"
if exist "%UXP%\Plugins\External\com.mrdoamba.afficheminute_1.0.0" rmdir /S /Q "%UXP%\Plugins\External\com.mrdoamba.afficheminute_1.0.0"
if exist "%UXP%\PluginsInfo\v1\PS.json" findstr /C:"com.mrdoamba.afficheminute" "%UXP%\PluginsInfo\v1\PS.json" >nul && del /Q "%UXP%\PluginsInfo\v1\PS.json"

echo.
echo Termine ! Redemarrez Photoshop puis ouvrez : Modules externes ^> Affiche Minute
pause
