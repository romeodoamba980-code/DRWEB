/*
 * Affiche Minute v2.0 — interface 3D animée (SVG + JavaScript, compatible panneaux UXP)
 *  - logo cube 3D en rotation
 *  - vignettes de modèles qui pivotent en 3D au survol
 *  - aperçu du modèle choisi qui tourne lentement et se retourne au changement
 *  - aperçu en direct du texte 3D
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const PI = Math.PI;

  /* ------------------------------------------------------------------
   * Mathématiques 3D
   * ------------------------------------------------------------------ */
  function projeter(x, y, z, rx, ry, d) {
    const cy = Math.cos(ry), sy = Math.sin(ry);
    const x1 = x * cy + z * sy, z1 = -x * sy + z * cy;
    const cx = Math.cos(rx), sx = Math.sin(rx);
    const y1 = y * cx - z1 * sx, z2 = y * sx + z1 * cx;
    const p = d / (d + z2);
    return [x1 * p, y1 * p, z2];
  }
  const pts = (a) => a.map((p) => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ");
  function hexRgb(h) { h = String(h || "#000").replace("#", ""); if (h.length === 3) h = h.split("").map((c) => c + c).join(""); return [0, 2, 4].map((i) => parseInt(h.substr(i, 2), 16) || 0); }
  function teinte(h, f) { const c = hexRgb(h), t = f < 0 ? 0 : 255, k = Math.min(1, Math.abs(f)); return "#" + c.map((v) => Math.round(v + (t - v) * k).toString(16).padStart(2, "0")).join(""); }
  function valide(v, def) { v = String(v || "").trim(); return /^#?[0-9a-fA-F]{6}$/.test(v) ? "#" + v.replace("#", "") : def; }

  /* ------------------------------------------------------------------
   * Données des vignettes (carte 60 × 80)
   * r = rectangle, c = cercle, p = polygone
   * ------------------------------------------------------------------ */
  const rayures = (y, h, col) => { const o = []; for (let x = -6; x < 66; x += 10) o.push({ t: "p", p: [[x, y], [x + 5, y], [x + 1, y + h], [x - 4, y + h]], c: col }); return o; };
  const MODELES = {
    impact: { nom: "Impact", desc: "Grand cercle, texte puissant", bg: "#E8590C", s: [
      { t: "c", x: 54, y: 4, r: 24, c: "#FFD43B" }, { t: "c", x: 6, y: 74, r: 14, c: "#FFFFFF", o: 0.12 },
      { t: "r", x: 7, y: 24, w: 14, h: 1.6, c: "#FFD43B" }, { t: "r", x: 7, y: 30, w: 38, h: 7, c: "#FFFFFF" }, { t: "r", x: 7, y: 40, w: 26, h: 3, c: "#FFD43B" },
      { t: "r", x: 7, y: 46, w: 42, h: 1.6, c: "#FFFFFF", o: 0.7 }, { t: "r", x: 7, y: 49, w: 34, h: 1.6, c: "#FFFFFF", o: 0.7 },
      { t: "c", x: 46, y: 18, r: 6, c: "#1A1A1A" }, { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#FFD43B" }] },
    photo: { nom: "Photo", desc: "Grande photo + panneau coloré", bg: "#0B3D91", s: [
      { t: "r", x: 0, y: 0, w: 60, h: 40, c: "#7C8A99" }, { t: "c", x: 22, y: 26, r: 9, c: "#95A3B2" }, { t: "r", x: 0, y: 39, w: 60, h: 2, c: "#FFC300" },
      { t: "r", x: 12, y: 47, w: 36, h: 7, c: "#FFFFFF" }, { t: "r", x: 17, y: 57, w: 26, h: 3, c: "#FFC300" }, { t: "c", x: 46, y: 12, r: 6, c: "#FFC300" },
      { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#FFC300" }] },
    epure: { nom: "Épuré", desc: "Fond clair, élégant, aéré", bg: "#FFFFFF", s: [
      { t: "r", x: 6, y: 14, w: 2, h: 24, c: "#1B7F4C" }, { t: "r", x: 11, y: 16, w: 34, h: 7, c: "#0F2E1F" }, { t: "r", x: 11, y: 26, w: 22, h: 3, c: "#1B7F4C" },
      { t: "r", x: 11, y: 32, w: 30, h: 1.5, c: "#0F2E1F", o: 0.5 }, { t: "r", x: 6, y: 44, w: 48, h: 26, c: "#A9B4BF", rr: 3 }, { t: "c", x: 50, y: 8, r: 5, c: "#1B7F4C" }] },
    promo: { nom: "Promo", desc: "Cercle d'offre, fond sombre", bg: "#2B0A0A", s: [
      { t: "c", x: 8, y: 6, r: 3, c: "#FCBF49", o: 0.7 }, { t: "c", x: 30, y: 23, r: 18, c: "#FCBF49" }, { t: "c", x: 30, y: 23, r: 16, c: "#D62828" },
      { t: "r", x: 21, y: 20, w: 18, h: 6, c: "#FFFFFF" }, { t: "r", x: 12, y: 48, w: 36, h: 6, c: "#FFFFFF" }, { t: "r", x: 18, y: 57, w: 24, h: 3, c: "#FCBF49" },
      { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#FCBF49" }] },
    soiree: { nom: "Soirée", desc: "Halos lumineux, titre néon", bg: "#141414", s: [
      { t: "c", x: 6, y: 8, r: 26, c: "#E8590C", o: 0.45 }, { t: "c", x: 54, y: 66, r: 22, c: "#FFD43B", o: 0.25 }, { t: "c", x: 44, y: 10, r: 7, c: "#FFFFFF", o: 0.12 },
      { t: "r", x: 9, y: 26, w: 42, h: 9, c: "#FFFFFF" }, { t: "r", x: 16, y: 38, w: 28, h: 3, c: "#FFD43B" }, { t: "r", x: 0, y: 54, w: 60, h: 8, c: "#FFD43B" },
      { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#FFFFFF" }] },
    culte: { nom: "Culte", desc: "Lumière, photo ronde, sérénité", bg: "#0F2E1F", s: [
      { t: "c", x: 30, y: 0, r: 36, c: "#F4D35E", o: 0.1 }, { t: "c", x: 30, y: 0, r: 24, c: "#F4D35E", o: 0.14 },
      { t: "c", x: 30, y: 17, r: 10, c: "#F4D35E" }, { t: "c", x: 30, y: 17, r: 9, c: "#A9B4BF" },
      { t: "r", x: 22, y: 33, w: 16, h: 0.8, c: "#F4D35E" }, { t: "r", x: 12, y: 37, w: 36, h: 6, c: "#FFFFFF" }, { t: "r", x: 18, y: 46, w: 24, h: 3, c: "#F4D35E" },
      { t: "r", x: 22, y: 53, w: 16, h: 0.8, c: "#F4D35E" }, { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#F4D35E" }] },
    immo: { nom: "Immobilier", desc: "Photo du bien + étiquette prix", bg: "#FFFFFF", s: [
      { t: "r", x: 0, y: 0, w: 60, h: 40, c: "#9AA5B1" }, { t: "p", p: [[12, 30], [24, 18], [36, 30]], c: "#C7D0D9" }, { t: "r", x: 16, y: 30, w: 16, h: 10, c: "#C7D0D9" },
      { t: "r", x: 32, y: 35, w: 24, h: 10, c: "#FFC300", rr: 2 }, { t: "r", x: 6, y: 50, w: 2, h: 14, c: "#0B3D91" },
      { t: "r", x: 11, y: 50, w: 32, h: 6, c: "#0A1A33" }, { t: "r", x: 11, y: 59, w: 22, h: 3, c: "#0B3D91" }, { t: "r", x: 0, y: 70, w: 60, h: 10, c: "#0B3D91" }] },
    produits: { nom: "Produits", desc: "Photo vedette, prix, galerie de produits", bg: "#E8590C", s: [
      { t: "c", x: 52, y: 4, r: 16, c: "#FFD43B", o: 0.5 }, { t: "r", x: 5, y: 10, w: 50, h: 28, c: "#1A1A1A", rr: 3 }, { t: "c", x: 30, y: 24, r: 8, c: "#7C8A99" },
      { t: "c", x: 49, y: 36, r: 6.5, c: "#FFD43B" }, { t: "r", x: 46, y: 35, w: 6, h: 2, c: "#1A1A1A" },
      { t: "r", x: 6, y: 42, w: 11, h: 11, c: "#FFFFFF", rr: 2 }, { t: "r", x: 19, y: 42, w: 11, h: 11, c: "#FFFFFF", rr: 2 }, { t: "r", x: 32, y: 42, w: 11, h: 11, c: "#FFFFFF", rr: 2 }, { t: "r", x: 45, y: 42, w: 9, h: 11, c: "#FFFFFF", rr: 2 },
      { t: "r", x: 12, y: 57, w: 36, h: 6, c: "#FFFFFF" }, { t: "r", x: 4, y: 71, w: 52, h: 6, c: "#FFD43B", rr: 3 }] },
    moderne: { nom: "Moderne", desc: "Dégradés, photo ronde, carte en verre", bg: "#5B21B6", s: [
      { t: "c", x: 52, y: 6, r: 26, c: "#FF4D9D", o: 0.85 }, { t: "c", x: 4, y: 70, r: 18, c: "#1E0730", o: 0.6 }, { t: "c", x: 40, y: 20, r: 12, c: "#FFFFFF" }, { t: "c", x: 40, y: 20, r: 11, c: "#A9B4BF" },
      { t: "r", x: 5, y: 37, w: 50, h: 30, c: "#FFFFFF", o: 0.14, rr: 3 }, { t: "r", x: 10, y: 42, w: 18, h: 2, c: "#FF4D9D" }, { t: "r", x: 10, y: 46, w: 34, h: 6, c: "#FFFFFF" },
      { t: "r", x: 10, y: 55, w: 26, h: 2, c: "#FFFFFF", o: 0.6 }, { t: "r", x: 10, y: 60, w: 18, h: 4, c: "#FF4D9D", rr: 2 }, { t: "r", x: 4, y: 71, w: 52, h: 6, c: "#FF4D9D", rr: 3 }] },
    chantier: { nom: "Chantier", desc: "Bandes de sécurité, BTP", bg: "#161616", s: [].concat(
      [{ t: "r", x: 0, y: 0, w: 60, h: 6, c: "#FFC300" }], rayures(0, 6, "#161616"),
      [{ t: "r", x: 0, y: 6, w: 60, h: 28, c: "#7C8A99" }, { t: "p", p: [[38, 34], [50, 18], [60, 34]], c: "#95A3B2" },
       { t: "r", x: 6, y: 40, w: 16, h: 1.6, c: "#FFC300" }, { t: "r", x: 6, y: 44, w: 38, h: 7, c: "#FFFFFF" }, { t: "r", x: 6, y: 54, w: 26, h: 3, c: "#FFC300" },
       { t: "c", x: 50, y: 34, r: 7, c: "#FFC300" }, { t: "r", x: 0, y: 62, w: 60, h: 6, c: "#FFC300" }], rayures(62, 6, "#161616"),
      [{ t: "r", x: 0, y: 70, w: 60, h: 10, c: "#FFC300" }]) }
  };

  /* Arrondi : renvoie les points du contour d'un rectangle */
  function contourRect(x, y, w, h, r) {
    if (!r) return [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
    const o = [], q = [[x + w - r, y + r, -PI / 2], [x + w - r, y + h - r, 0], [x + r, y + h - r, PI / 2], [x + r, y + r, PI]];
    for (const [cx, cy, a0] of q) for (let i = 0; i <= 4; i++) { const a = a0 + (PI / 2) * (i / 4); o.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); }
    return o;
  }
  function contourCercle(cx, cy, r, n) { const o = []; n = n || 22; for (let i = 0; i < n; i++) { const a = (2 * PI * i) / n; o.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return o; }
  /* Découpe un polygone convexe/simple dans le rectangle de la carte (Sutherland–Hodgman) */
  function decouper(poly, W, H) {
    const plans = [[(p) => p[0] >= 0, (a, b) => [0, a[1] + (b[1] - a[1]) * (0 - a[0]) / (b[0] - a[0])]],
                   [(p) => p[0] <= W, (a, b) => [W, a[1] + (b[1] - a[1]) * (W - a[0]) / (b[0] - a[0])]],
                   [(p) => p[1] >= 0, (a, b) => [a[0] + (b[0] - a[0]) * (0 - a[1]) / (b[1] - a[1]), 0]],
                   [(p) => p[1] <= H, (a, b) => [a[0] + (b[0] - a[0]) * (H - a[1]) / (b[1] - a[1]), H]]];
    let out = poly;
    for (const [dedans, inter] of plans) {
      const inp = out; out = [];
      for (let i = 0; i < inp.length; i++) {
        const a = inp[i], b = inp[(i + 1) % inp.length];
        if (dedans(b)) { if (!dedans(a)) out.push(inter(a, b)); out.push(b); }
        else if (dedans(a)) out.push(inter(a, b));
      }
      if (!out.length) break;
    }
    return out;
  }

  /* Rendu d'une carte 3D (épaisseur, reflet brillant, ombre au sol) */
  function carte3D(m, rx, ry, L, Hh, echelle, ombre) {
    const W = 60, H = 80, ep = 4, d = 170, cxp = L / 2, cyp = Hh / 2 - (ombre ? 8 : 0);
    const P = (x, y, z) => { const p = projeter((x - W / 2) * echelle, (y - H / 2) * echelle, z * echelle, rx, ry, d * echelle); return [cxp + p[0], cyp + p[1], p[2]]; };
    let svg = "";
    if (ombre) {
      const lw = Math.max(12, Math.abs(Math.cos(ry)) * W * echelle * 0.9 + 14);
      svg += `<ellipse cx="${cxp}" cy="${cyp + H * echelle * 0.5 + 16}" rx="${(lw / 2).toFixed(1)}" ry="7" fill="#000000" opacity="0.45"/>`;
      svg += `<ellipse cx="${cxp}" cy="${cyp + H * echelle * 0.5 + 16}" rx="${(lw / 3).toFixed(1)}" ry="4" fill="#FF5A2A" opacity="0.25"/>`;
    }
    const cad = contourRect(0, 0, W, H, 4);
    const av = cad.map(([x, y]) => P(x, y, 0)), ar = cad.map(([x, y]) => P(x, y, ep));
    // normale de la face avant : visible si z de la normale < 0
    const nz = Math.cos(rx) * Math.cos(ry);
    const faceAvant = nz > 0;
    // tranches (côtés)
    const cotes = [];
    for (let i = 0; i < cad.length; i++) {
      const j = (i + 1) % cad.length, q = [av[i], av[j], ar[j], ar[i]];
      cotes.push({ q, z: (q[0][2] + q[1][2] + q[2][2] + q[3][2]) / 4 });
    }
    cotes.sort((a, b) => b.z - a.z);
    const tranche = teinte(m.bg === "#FFFFFF" ? "#C9CFD8" : m.bg, -0.45);
    if (!faceAvant) {
      svg += `<polygon points="${pts(av)}" fill="#20252E"/>`;
      for (const c of cotes) svg += `<polygon points="${pts(c.q)}" fill="${tranche}"/>`;
      svg += `<polygon points="${pts(ar)}" fill="#2A303B" stroke="#3A4250" stroke-width="1"/>`;
      // dos de la carte : logo AM
      const dos = contourCercle(W / 2, H / 2, 12).map(([x, y]) => P(x, y, ep + 0.1));
      svg += `<polygon points="${pts(dos)}" fill="#FF5A2A" opacity="0.85"/>`;
      return svg;
    }
    for (const c of cotes) svg += `<polygon points="${pts(c.q)}" fill="${tranche}"/>`;
    svg += `<polygon points="${pts(av)}" fill="${m.bg}"/>`;
    for (const s of m.s) {
      let poly;
      if (s.t === "r") poly = contourRect(s.x, s.y, s.w, s.h, s.rr || 0);
      else if (s.t === "c") poly = contourCercle(s.x, s.y, s.r);
      else poly = s.p;
      poly = decouper(poly, W, H);
      if (poly.length < 3) continue;
      svg += `<polygon points="${pts(poly.map(([x, y]) => P(x, y, -0.05)))}" fill="${s.c}"${s.o != null ? ` opacity="${s.o}"` : ""}/>`;
    }
    // reflet brillant qui glisse avec la rotation
    const dec = 30 + ry * 70;
    const bande = decouper([[dec - 4, 0], [dec + 10, 0], [dec - 14, H], [dec - 28, H]], W, H);
    if (bande.length > 2) svg += `<polygon points="${pts(bande.map(([x, y]) => P(x, y, -0.1)))}" fill="#FFFFFF" opacity="0.13"/>`;
    svg += `<polygon points="${pts(av)}" fill="none" stroke="#FFFFFF" stroke-opacity="0.18" stroke-width="1"/>`;
    return svg;
  }

  /* ------------------------------------------------------------------
   * 1. Logo cube 3D
   * ------------------------------------------------------------------ */
  const CUBE_S = [[-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1], [-1, -1, 1], [1, -1, 1], [1, 1, 1], [-1, 1, 1]];
  const CUBE_F = [[[0, 1, 2, 3], "#FF6A1A"], [[5, 4, 7, 6], "#7C3AED"], [[4, 0, 3, 7], "#FF2E7E"], [[1, 5, 6, 2], "#FF2E7E"], [[4, 5, 1, 0], "#FFB020"], [[3, 2, 6, 7], "#C2410C"]];
  function logo(t) {
    const rx = -0.5 + Math.sin(t * 0.7) * 0.15, ry = t * 0.9, k = 13, c = 26;
    const P = CUBE_S.map(([x, y, z]) => { const p = projeter(x * k, y * k, z * k, rx, ry, 90); return [c + p[0], c + p[1], p[2]]; });
    const faces = CUBE_F.map(([idx, col]) => {
      const q = idx.map((i) => P[i]);
      const ax = q[1][0] - q[0][0], ay = q[1][1] - q[0][1], bx = q[2][0] - q[0][0], by = q[2][1] - q[0][1];
      return { q, col, vis: ax * by - ay * bx < 0, z: q.reduce((s, p) => s + p[2], 0) / 4, lum: Math.max(0.15, (ax * by - ay * bx) / -(2 * k * k * 2)) };
    }).filter((f) => f.vis).sort((a, b) => b.z - a.z);
    let s = `<ellipse cx="26" cy="48" rx="15" ry="3" fill="#000000" opacity="0.35"/>`;
    for (const f of faces) {
      const shade = Math.min(1, 0.55 + f.lum * 0.6);
      s += `<polygon points="${pts(f.q)}" fill="${teinte(f.col, shade - 1)}" stroke="#FFFFFF" stroke-opacity="0.35" stroke-width="0.8"/>`;
    }
    // « A » au centre de la face la plus proche
    const proche = faces[faces.length - 1];
    if (proche) {
      const cxA = proche.q.reduce((s, p) => s + p[0], 0) / 4, cyA = proche.q.reduce((s, p) => s + p[1], 0) / 4;
      s += `<text x="${cxA.toFixed(1)}" y="${(cyA + 5).toFixed(1)}" text-anchor="middle" font-family="Arial Black" font-weight="900" font-size="14" fill="#FFFFFF">A</text>`;
    }
    return `<svg width="52" height="52" viewBox="0 0 52 52">${s}</svg>`;
  }

  /* ------------------------------------------------------------------
   * 2. Aperçu du modèle (rotation lente + retournement)
   * ------------------------------------------------------------------ */
  const apercu = { modele: null, affiche: null, flip: 0 };
  function modeleActif() { const t = document.querySelector(".tuile.actif"); return t ? t.getAttribute("data-m") : "impact"; }
  function rendreApercu(t) {
    const el = $("apercuModele"); if (!el) return;
    const m = modeleActif();
    if (apercu.affiche === null) apercu.affiche = m;
    if (m !== apercu.affiche && apercu.flip === 0) apercu.flip = 0.0001;
    let ry = Math.sin(t * 0.8) * 0.42, rx = Math.sin(t * 0.5) * 0.08 - 0.04;
    if (apercu.flip > 0) {
      apercu.flip += 0.09;
      if (apercu.flip >= 1 && apercu.affiche !== m) { apercu.affiche = m; majInfos(m); }
      if (apercu.flip >= 2) apercu.flip = 0;
      const f = apercu.flip;
      ry = f < 1 ? ry + f * (PI / 2) : ry - (2 - f) * (PI / 2);
    }
    const L = Math.max(160, el.offsetWidth || 260), H = 196;
    const md = MODELES[apercu.affiche] || MODELES.impact;
    el.innerHTML = `<svg width="${L}" height="${H}" viewBox="0 0 ${L} ${H}">${carte3D(md, rx, ry, L, H, 1.7, true)}</svg>`;
  }
  function majInfos(m) {
    const md = MODELES[m] || MODELES.impact;
    if ($("apercuNom")) $("apercuNom").textContent = md.nom;
    if ($("apercuDesc")) $("apercuDesc").textContent = md.desc;
  }

  /* ------------------------------------------------------------------
   * 3. Vignettes : pivot 3D au survol
   * ------------------------------------------------------------------ */
  const survol = {};
  function rendreVignette(el, t) {
    const m = el.getAttribute("data-v"), md = MODELES[m]; if (!md) return;
    const s = survol[m];
    let rx = 0, ry = 0;
    if (s) { const k = Math.min(1, (t - s) * 3); ry = Math.sin((t - s) * 2.4) * 0.55 * k; rx = -0.12 * k; }
    const L = Math.max(50, el.offsetWidth || 64), H = 74;
    el.innerHTML = `<svg width="${L}" height="${H}" viewBox="0 0 ${L} ${H}">${carte3D(md, rx, ry, L, H, 0.82, false)}</svg>`;
  }

  /* ------------------------------------------------------------------
   * 4. Aperçu en direct du texte 3D
   * ------------------------------------------------------------------ */
  const RENDU3D = {
    cartoon: { face: (F) => F, prof: (T) => T, contour: (T) => teinte(T, 0.3), trait: (T) => teinte(T, 0.15), etincelle: true },
    luxe: { face: () => "#FFFFFF", prof: () => "#C9961A", degradeProf: ["#8A5A00", "#F2C94C"], trait: () => "#D4A017", traitL: 2.2 },
    verre: { verre: true },
    gaming: { face: () => "#CDD1D6", prof: (T) => teinte(T, -0.45), contour: (T) => T, contourL: 9, grain: true },
    graffiti: { face: (F) => F, prof: (T) => T, trait: (T) => teinte(T, -0.3), traitL: 2.5, lignes: true },
    eclat: { face: (F) => F, prof: (T) => T, degradeProf: null, neon: "#2EC5FF", reflet: true },
    extrude: { face: (F) => F, prof: (T) => T },
    relief: { face: (F) => F, plat: true, ombre: (T) => T },
    or: { face: () => "#E8B84A", prof: () => "#5C3D00", trait: () => "#FFF1A8", traitL: 0.8 },
    chrome: { face: () => "#D8DEE5", prof: () => "#30363C", trait: () => "#FFFFFF", traitL: 0.8 },
    neon: { face: (F) => F, prof: (T) => T, halo: true },
    sticker: { face: (F) => F, plat: true, contour: () => "#FFFFFF", contourL: 7, ombreDure: (T) => T }
  };
  const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  function rendreTexte3D(t) {
    const el = $("t3Apercu"); if (!el) return;
    const L = Math.max(180, el.offsetWidth || 280), H = 132;
    let txt = (($("t3Texte") && $("t3Texte").value) || "TEXTE 3D").split(/\n/)[0].trim() || "TEXTE 3D";
    if ($("t3Maj") && $("t3Maj").checked) txt = txt.toUpperCase();
    if (txt.length > 16) txt = txt.substr(0, 15) + "…";
    const style = ($("t3Style") && $("t3Style").value) || "cartoon";
    const R = RENDU3D[style] || RENDU3D.cartoon;
    const F = valide($("t3Face") && $("t3Face").value, "#FFFFFF"), T = valide($("t3Tranche") && $("t3Tranche").value, "#D6006F");
    const prof = parseInt(($("t3Prof") && $("t3Prof").value) || 14, 10);
    const base = parseFloat(($("t3Dir") && $("t3Dir").value) || 45);
    const sel = $("t3Police"); let police = "Arial Black";
    try { const o = sel && sel.options && sel.options[sel.selectedIndex]; if (o && o.textContent) police = o.textContent; } catch (e) {}
    const fs = Math.min(52, (L - 40) / (txt.length * 0.82));
    const cx = L / 2, cy = H / 2 + fs * 0.34;
    const dir = (base + Math.sin(t * 1.1) * 22) * PI / 180;            // rotation de la profondeur
    const depth = fs * prof / 100 * 1.6;
    const N = R.plat || R.verre ? 0 : Math.max(6, Math.round(depth / 1.2));
    const txtEl = (x, y, attrs) => `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" text-anchor="middle" font-family="${esc(police)}" font-weight="900" font-size="${fs.toFixed(1)}" ${attrs}>${esc(txt)}</text>`;
    let s = "";
    const sxy = (i) => [cx + Math.cos(dir) * depth * (i / Math.max(1, N)), cy + Math.sin(dir) * depth * (i / Math.max(1, N))];
    if (R.neon) s += txtEl(cx, cy - fs * 0.08, `fill="none" stroke="${R.neon}" stroke-width="1.6" opacity="0.9" transform="translate(${cx} ${cy}) scale(1.14) translate(${-cx} ${-cy})"`);
    if (R.contour) { const [x, y] = sxy(N); s += txtEl(x, y, `fill="${R.contour(T)}" stroke="${R.contour(T)}" stroke-width="${R.contourL || 6}" stroke-linejoin="round"`); }
    if (R.ombreDure) s += txtEl(cx + Math.cos(dir) * fs * 0.12, cy + Math.sin(dir) * fs * 0.12, `fill="${R.ombreDure(T)}" stroke="${R.ombreDure(T)}" stroke-width="7" stroke-linejoin="round"`);
    if (R.ombre) s += txtEl(cx + Math.cos(dir) * fs * 0.08, cy + Math.sin(dir) * fs * 0.08, `fill="${R.ombre(T)}" opacity="0.7"`);
    for (let i = N; i >= 1; i--) {
      const [x, y] = sxy(i);
      let col = R.prof ? R.prof(T) : T;
      if (R.degradeProf) col = teinte(R.degradeProf[1], -(i / N) * 0.55);
      else col = teinte(col, -(i / N) * 0.35);
      s += txtEl(x, y, `fill="${col}"${R.lignes ? ` stroke="${teinte(T, -0.55)}" stroke-width="0.6"` : ""}`);
    }
    if (R.verre) {
      s += txtEl(cx + 3, cy + 4, `fill="${teinte(T, -0.3)}" opacity="0.25"`);
      s += txtEl(cx, cy, `fill="${T}" fill-opacity="0.18" stroke="${T}" stroke-width="2.4"`);
      s += txtEl(cx - 1, cy - 1.5, `fill="none" stroke="#FFFFFF" stroke-width="0.9" opacity="0.85"`);
      for (const [bx, by, br] of [[0.1, 0.25, 7], [0.62, 0.08, 9], [0.78, 0.2, 3.5], [0.9, 0.72, 5]]) {
        const X = L * bx, Y = H * by + Math.sin(t * 1.6 + bx * 9) * 3;
        s += `<circle cx="${X.toFixed(1)}" cy="${Y.toFixed(1)}" r="${br}" fill="#FFFFFF" fill-opacity="0.08" stroke="#FFFFFF" stroke-opacity="0.7" stroke-width="0.8"/>`;
        s += `<circle cx="${(X - br * 0.35).toFixed(1)}" cy="${(Y - br * 0.35).toFixed(1)}" r="${(br * 0.25).toFixed(1)}" fill="#FFFFFF" opacity="0.8"/>`;
      }
    } else {
      const face = R.face ? R.face(F) : F;
      const trait = R.trait ? ` stroke="${R.trait(T)}" stroke-width="${R.traitL || 1.4}"` : "";
      if (R.halo) for (const k of [9, 5]) s += txtEl(cx, cy, `fill="none" stroke="${face}" stroke-width="${k}" opacity="${k === 9 ? 0.18 : 0.3}" stroke-linejoin="round"`);
      s += txtEl(cx, cy, `fill="${face}"${trait}`);
      // brillance du haut des lettres
      s += txtEl(cx, cy - fs * 0.03, `fill="#FFFFFF" opacity="${style === "luxe" || style === "cartoon" ? 0.28 : 0.14}" transform="translate(0 ${(-fs * 0.02).toFixed(1)})"`);
      if (R.grain) for (let i = 0; i < 70; i++) { const gx = cx + (((i * 73) % 100) / 100 - 0.5) * txt.length * fs * 0.6, gy = cy - fs * 0.7 + ((i * 37) % 100) / 100 * fs * 0.7; s += `<circle cx="${gx.toFixed(1)}" cy="${gy.toFixed(1)}" r="0.7" fill="#3A3F44" opacity="0.55"/>`; }
    }
    if (R.etincelle || R.reflet) {
      const ex = R.reflet ? cx : cx + txt.length * fs * 0.3, ey = R.reflet ? cy + fs * 0.05 : cy - fs * 0.75;
      const k = 0.75 + Math.sin(t * 4) * 0.25;
      s += `<ellipse cx="${ex.toFixed(1)}" cy="${ey.toFixed(1)}" rx="${(fs * (R.reflet ? 1.6 : 0.5) * k).toFixed(1)}" ry="1.2" fill="#FFFFFF"/>`;
      s += `<ellipse cx="${ex.toFixed(1)}" cy="${ey.toFixed(1)}" rx="1.2" ry="${(fs * 0.35 * k).toFixed(1)}" fill="#FFFFFF"/>`;
      s += `<circle cx="${ex.toFixed(1)}" cy="${ey.toFixed(1)}" r="${(3 * k).toFixed(1)}" fill="#FFFFFF" opacity="0.9"/>`;
    }
    el.innerHTML = `<svg width="${L}" height="${H}" viewBox="0 0 ${L} ${H}">${s}</svg>`;
  }

  /* ------------------------------------------------------------------
   * Boutons « div » : état occupé (remplace disabled)
   * ------------------------------------------------------------------ */
  function majBoutons() {
    document.querySelectorAll("[data-btn]").forEach((b) => {
      const occ = !!b.disabled;
      const c = occ ? "cta occupe" : "cta";
      if (b.className !== c) b.className = c;
    });
  }
  document.addEventListener("click", (e) => {
    let n = e.target;
    while (n && n !== document) {
      if (n.getAttribute && n.getAttribute("data-btn") && n.disabled) { e.stopPropagation(); e.preventDefault(); return; }
      n = n.parentNode;
    }
  }, true);

  /* ------------------------------------------------------------------
   * Boucle d'animation
   * ------------------------------------------------------------------ */
  function pageVisible(id) { const p = $(id); return p && p.style.display !== "none"; }
  document.querySelectorAll(".tuile").forEach((tu) => {
    const m = tu.getAttribute("data-m");
    tu.addEventListener("mouseenter", () => { survol[m] = Date.now() / 1000; });
    tu.addEventListener("mouseleave", () => { delete survol[m]; const v = tu.querySelector(".vignette"); if (v) rendreVignette(v, 0); });
  });
  majInfos(modeleActif());
  document.querySelectorAll(".vignette").forEach((v) => rendreVignette(v, 0));

  /* Mode économe : on n'anime que quelques secondes après une action,
   * jamais pendant une génération, et on peut tout couper. */
  let animOn = true;
  try { animOn = localStorage.getItem("afm_anim") !== "0"; } catch (e) {}
  let reveil = Date.now() / 1000;
  const DUREE = 5;                       // secondes d'animation après une action
  const reveiller = () => { reveil = Date.now() / 1000; };
  ["click", "input", "change", "mousedown", "wheel"].forEach((ev) => document.addEventListener(ev, reveiller, true));
  let dernierMvt = 0;
  document.addEventListener("mousemove", () => { const t = Date.now(); if (t - dernierMvt > 400) { dernierMvt = t; reveiller(); } }, true);

  function occupe() {
    let o = false;
    document.querySelectorAll("[data-btn]").forEach((b) => { if (b.disabled) o = true; });
    return o;
  }
  let derniereCle3D = "", dernierModele = "", figeLogo = false, figeApercu = false;
  function cle3D() {
    const v = (id) => ($(id) && ($(id).value != null ? $(id).value : "")) || "";
    return [v("t3Texte"), v("t3Style"), v("t3Face"), v("t3Tranche"), v("t3Prof"), v("t3Dir"), v("t3Police"), $("t3Maj") && $("t3Maj").checked].join("|");
  }
  function image(t) {
    if (occupe()) { majBoutons(); return; }       // pendant la génération : aucune animation
    const eveille = animOn && (t - reveil < DUREE || Object.keys(survol).length > 0 || apercu.flip > 0);
    const lg = $("logo3d");
    if (lg && (eveille || !figeLogo)) { lg.innerHTML = logo(eveille ? t : 0.6); figeLogo = !eveille; }
    if (pageVisible("pageAffiche")) {
      const m = modeleActif();
      if (m !== dernierModele) { dernierModele = m; reveiller(); figeApercu = false; }
      if (eveille || !figeApercu) { rendreApercu(eveille ? t : 0); figeApercu = !eveille && apercu.flip === 0; }
      document.querySelectorAll(".vignette").forEach((v) => { if (survol[v.getAttribute("data-v")]) rendreVignette(v, t); });
    }
    if (pageVisible("pageTexte3D")) {
      const k = cle3D();
      if (k !== derniereCle3D) { derniereCle3D = k; reveiller(); }
      if (eveille || k !== derniereCle3D || !$("t3Apercu").innerHTML) rendreTexte3D(eveille ? t : 1.2);
    }
    majBoutons();
  }
  function boucle() {
    try { image(Date.now() / 1000); } catch (e) { console.error(e); }
    const t = Date.now() / 1000, eveille = animOn && t - reveil < DUREE;
    setTimeout(boucle, eveille ? 90 : 400);    // ~11 images/s quand ça bouge, presque rien au repos
  }
  boucle();

  // Interrupteur des animations (pied de page)
  const inter = $("btnAnim");
  if (inter) {
    const maj = () => { inter.textContent = animOn ? "Animations 3D : activées" : "Animations 3D : désactivées"; };
    inter.addEventListener("click", () => {
      animOn = !animOn; maj();
      try { localStorage.setItem("afm_anim", animOn ? "1" : "0"); } catch (e) {}
      figeLogo = false; figeApercu = false;
    });
    maj();
  }
})();
