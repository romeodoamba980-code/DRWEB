/*
 * Affiche Minute v3.3 — plugin UXP pour Photoshop 2023+ (v24 et plus)
 * Auteur : Mr Doamba
 *
 * Génère en un clic une affiche entièrement modifiable (calques nommés :
 * fond, formes, textes, photo dans un masque d'écrêtage, logo).
 */

const { app, core, action, constants } = require("photoshop");
const { batchPlay } = action;
const uxp = require("uxp");
const fs = uxp.storage.localFileSystem;

// ⚠️ Paiement de la licence (modifiable ici)
const PAIEMENT = {
  prix: "",                                   // ex. « 10 000 F CFA » (laisser vide pour ne pas l'afficher)
  orange: "+226 66 54 05 35",                 // Orange Money
  moov: "+226 73 06 10 50",                   // Moov Money
  whatsapp: "22673061050",                    // numéro WhatsApp qui reçoit les preuves de paiement (sans + ni espaces)
  boutique: "https://romeodoamba980-code.github.io/MrDoamba/outils/boutique.html?produit=affiche-minute"
};
const URL_ACHAT = "https://wa.me/" + PAIEMENT.whatsapp + "?text=" + encodeURIComponent("Bonjour, je viens de payer une licence Affiche Minute. Voici la capture de mon paiement :");

/* =====================================================================
 * LICENCE
 * Clé au format AFM-XXXX-XXXX-XXXX. Le dernier bloc est une signature
 * calculée à partir des deux premiers. Même algorithme que gen-cles.html.
 * ===================================================================== */
const ALPHA = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const SEL = "MrDoamba|AfficheMinute|v1|BF";

function fnv(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}
function signature(a, b) {
  let h = fnv(SEL + a + b + SEL.length);
  let out = "";
  for (let i = 0; i < 4; i++) { out += ALPHA[h & 31]; h = h >>> 5; }
  return out;
}
function verifierCle(k) {
  const c = String(k || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (c.length !== 15 || c.substr(0, 3) !== "AFM") return false;
  const a = c.substr(3, 4), b = c.substr(7, 4), s = c.substr(11, 4);
  for (const ch of a + b + s) if (ALPHA.indexOf(ch) < 0) return false;
  return signature(a, b) === s;
}

/* =====================================================================
 * DONNÉES
 * ===================================================================== */
const FORMATS = {
  a4:      { label: "A4 portrait (impression 300 dpi)", w: 2480, h: 3508, print: true },
  a5:      { label: "A5 flyer (impression 300 dpi)",    w: 1748, h: 2480, print: true },
  a3:      { label: "A3 portrait (impression 300 dpi)", w: 3508, h: 4961, print: true },
  carre:   { label: "Carré 1080 × 1080 (Facebook / Instagram)", w: 1080, h: 1080 },
  story:   { label: "Story / Statut WhatsApp 1080 × 1920",      w: 1080, h: 1920 },
  paysage: { label: "Paysage 1920 × 1080 (bannière, écran)",    w: 1920, h: 1080 }
};

const PALETTES = [
  { nom: "Orange énergie", fond: "#E8590C", accent: "#FFD43B", texte: "#FFFFFF", sombre: "#1A1A1A" },
  { nom: "Bleu pro",       fond: "#0B3D91", accent: "#FFC300", texte: "#FFFFFF", sombre: "#0A1A33" },
  { nom: "Vert nature",    fond: "#1B7F4C", accent: "#F4D35E", texte: "#FFFFFF", sombre: "#0F2E1F" },
  { nom: "Rouge promo",    fond: "#D62828", accent: "#FCBF49", texte: "#FFFFFF", sombre: "#2B0A0A" },
  { nom: "Nuit élégante",  fond: "#111111", accent: "#C9A227", texte: "#F5F1E6", sombre: "#000000" },
  { nom: "Violet festif",  fond: "#6A1B9A", accent: "#FF4D9D", texte: "#FFFFFF", sombre: "#1E0730" }
];

const POLICES_TITRE_PREF = ["Montserrat-ExtraBold", "Montserrat-Black", "Anton-Regular", "BebasNeue-Regular", "BebasNeue", "Impact", "Arial-Black", "Arial-BoldMT"];
const POLICES_TEXTE_PREF = ["Montserrat-Medium", "Montserrat-Regular", "Poppins-Regular", "OpenSans-Regular", "SegoeUI", "ArialMT"];

const state = { modele: "impact", photo: null, logo: null, palette: 0, fondLogo: "auto", autoCadrage: true, produits: [], moderne: true, formeCadres: "auto" };

/* =====================================================================
 * OUTILS
 * ===================================================================== */
const $ = (id) => document.getElementById(id);
function lsGet(k, d = null) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }

const px = (v) => ({ _unit: "pixelsUnit", _value: v });
const pct = (v) => ({ _unit: "percentUnit", _value: v });
const pt = (v) => ({ _unit: "pointsUnit", _value: Math.max(1, Math.min(1290, v)) });

function hexValide(hex) { return /^#?([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(String(hex || "").trim()); }
function hexToRgb(hex) {
  let h = String(hex || "").replace("#", "").trim();
  if (h.length === 3) h = h.split("").map((c) => c + c).join("");
  if (!/^[0-9a-fA-F]{6}$/.test(h)) h = "000000";
  return { r: parseInt(h.substr(0, 2), 16), g: parseInt(h.substr(2, 2), 16), b: parseInt(h.substr(4, 2), 16) };
}
function rgb(hex) { const c = hexToRgb(hex); return { _obj: "RGBColor", red: c.r, grain: c.g, blue: c.b }; }

async function bp(d) { return batchPlay(Array.isArray(d) ? d : [d], {}); }
function actif() { return app.activeDocument.activeLayers[0]; }

function couper(txt, max) {
  max = Math.max(4, Math.floor(max));
  return String(txt || "").split(/\r\n|\n|\r/).map((par) => {
    const mots = par.split(/\s+/).filter(Boolean);
    const lignes = [];
    let cur = "";
    for (const m of mots) {
      if (!cur) cur = m;
      else if ((cur + " " + m).length <= max) cur += " " + m;
      else { lignes.push(cur); cur = m; }
    }
    if (cur) lignes.push(cur);
    return lignes.join("\n");
  }).join("\n");
}
function carsPour(largeur, taille, facteur) { return Math.max(6, Math.floor(largeur / (taille * facteur))); }

/* =====================================================================
 * PRIMITIVES PHOTOSHOP
 * ===================================================================== */
async function nommer(nom, opacite) {
  const l = actif();
  try { if (l.isClippingMask) l.isClippingMask = false; } catch (e) {}
  l.name = nom;
  if (opacite != null && opacite < 100) l.opacity = opacite;
  return l;
}

function degradeGradient(stops, transp) {
  return { _obj: "gradientClassEvent", name: "Affiche Minute", gradientForm: { _enum: "gradientForm", _value: "customStops" }, interfaceIconFrameDimmed: 4096,
    colors: stops.map(([hex, loc]) => ({ _obj: "colorStop", color: rgb(hex), type: { _enum: "colorStopType", _value: "userStop" }, location: Math.round(loc * 4096), midpoint: 50 })),
    transparency: (transp || [[100, 0], [100, 1]]).map(([o, loc]) => ({ _obj: "transferSpec", opacity: pct(o), location: Math.round(loc * 4096), midpoint: 50 })) };
}
function typeDegrade(stops, angle, radial, transp, offset, echelle) {
  const t = { _obj: "gradientLayer", angle: { _unit: "angleUnit", _value: angle || 90 },
    type: { _enum: "gradientType", _value: radial ? "radial" : "linear" }, gradient: degradeGradient(stops, transp) };
  if (offset) t.offset = { _obj: "paint", horizontal: pct(offset[0]), vertical: pct(offset[1]) };
  if (echelle) t.scale = pct(echelle);
  return t;
}
const contraste = (hex) => { const c = hexToRgb(hex); return (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) > 150 ? "#141414" : "#FFFFFF"; };
async function fond(hex) {
  if (state.moderne === false) {
    await bp({ _obj: "make", _target: [{ _ref: "contentLayer" }],
      using: { _obj: "contentLayer", type: { _obj: "solidColorLayer", color: rgb(hex) } } });
    return nommer("Fond");
  }
  await bp({ _obj: "make", _target: [{ _ref: "contentLayer" }],
    using: { _obj: "contentLayer", type: typeDegrade([[nuance(hex, -0.38), 0], [hex, 0.55], [nuance(hex, 0.14), 1]], 100) } });
  const f = await nommer("Fond (dégradé)");
  await bp({ _obj: "make", _target: [{ _ref: "contentLayer" }],
    using: { _obj: "contentLayer", type: typeDegrade([["#FFFFFF", 0], ["#FFFFFF", 1]], 90, true, [[30, 0], [0, 1]], [-28, -32], 85) } });
  await nommer("Halo lumineux");
  return f;
}
async function forme(nom, type, x, y, w, h, hex, opacite = 100, rayon = 0) {
  const shape = { _obj: type, unitValueQuadVersion: 1,
    top: px(Math.round(y)), left: px(Math.round(x)), bottom: px(Math.round(y + h)), right: px(Math.round(x + w)) };
  if (type === "rectangle" && rayon > 0) {
    shape.topLeft = px(rayon); shape.topRight = px(rayon); shape.bottomLeft = px(rayon); shape.bottomRight = px(rayon);
  }
  const enDegrade = state.moderne !== false && /^(Décor|Halo|Lumière|Badge|Cercle|Étiquette|Bandeau|Bande chantier$)/.test(nom);
  const type_ = enDegrade ? typeDegrade([[nuance(hex, 0.22), 0], [nuance(hex, -0.16), 1]], 120) : { _obj: "solidColorLayer", color: rgb(hex) };
  await bp({ _obj: "make", _target: [{ _ref: "contentLayer" }],
    using: { _obj: "contentLayer", type: type_, shape } });
  return nommer(nom, opacite);
}

async function texte(nom, contenu, o) {
  const s = String(contenu).replace(/\r\n|\n/g, "\r");
  const style = { _obj: "textStyle", fontPostScriptName: o.police, size: pt(o.taille),
    color: rgb(o.couleur), tracking: o.interlettre || 0 };
  if (o.interligne) { style.autoLeading = false; style.leading = pt(o.interligne); }
  await bp({ _obj: "make", _target: [{ _ref: "textLayer" }],
    using: { _obj: "textLayer", textKey: s,
      textClickPoint: { _obj: "paint", horizontal: pct(50), vertical: pct(50) },
      textStyleRange: [{ _obj: "textStyleRange", from: 0, to: s.length, textStyle: style }],
      paragraphStyleRange: [{ _obj: "paragraphStyleRange", from: 0, to: s.length,
        paragraphStyle: { _obj: "paragraphStyle", align: { _enum: "alignmentType", _value: o.align || "center" } } }] } });
  return nommer(nom, o.opacite);
}

function bornes(l) {
  // Lecture directe dans Photoshop (évite les dimensions « en cache » après un redimensionnement)
  try {
    const r = batchPlay([{ _obj: "get", _target: [{ _property: "boundsNoEffects" }, { _ref: "layer", _id: l.id }] }], { synchronousExecution: true });
    const b = r && r[0] && r[0].boundsNoEffects;
    if (b && b.top != null) {
      const v = (o) => (o && typeof o === "object" ? o._value : o);
      const x = v(b.left), y = v(b.top), w = v(b.right) - x, h = v(b.bottom) - y;
      if (isFinite(x) && isFinite(y) && w >= 0 && h >= 0) return { x, y, w, h };
    }
  } catch (e) {}
  const b = l.boundsNoEffects || l.bounds;
  return { x: b.left, y: b.top, w: b.right - b.left, h: b.bottom - b.top };
}
async function ajuster(l, maxW, maxH) {
  const b = bornes(l);
  let r = 1;
  if (maxW && b.w > maxW) r = Math.min(r, maxW / b.w);
  if (maxH && b.h > maxH) r = Math.min(r, maxH / b.h);
  if (r < 0.999) await l.scale(r * 100, r * 100);
  return bornes(l);
}
async function placerA(l, x, y) { const b = bornes(l); await l.translate(x - b.x, y - b.y); }
async function centrer(l, cx, cy) { const b = bornes(l); await l.translate(cx - (b.x + b.w / 2), cy - (b.y + b.h / 2)); }

async function placerImage(fichier, nom) {
  const token = await fs.createSessionToken(fichier);
  await bp({ _obj: "placeEvent", null: { _path: token, _kind: "local" },
    freeTransformCenterState: { _enum: "quadCenterState", _value: "QCSAverage" },
    offset: { _obj: "offset", horizontal: px(0), vertical: px(0) } });
  return nommer(nom);
}
async function couvrir(l, z) {
  let b = bornes(l);
  const r = Math.max(z.w / b.w, z.h / b.h);
  await l.scale(r * 100, r * 100);
  b = bornes(l);
  await l.translate(z.x + (z.w - b.w) / 2 - b.x, z.y + (z.h - b.h) / 2 - b.y);
}

/* ---------- Cadrage automatique (détection du sujet) ---------- */
async function boiteSelection() {
  const r = await batchPlay([{ _obj: "get", _target: [{ _property: "selection" }, { _ref: "document", _enum: "ordinal", _value: "targetEnum" }] }], {});
  const s = r && r[0] && r[0].selection;
  if (!s || s.top == null) return null;
  const v = (o) => (o && typeof o === "object" ? o._value : o);
  const x = v(s.left), y = v(s.top), w = v(s.right) - x, h = v(s.bottom) - y;
  return isFinite(w) && isFinite(h) ? { x, y, w, h } : null;
}
async function analyserSujet(l) {
  try {
    await selectionnerCalque(l.id);
    await bpx({ _obj: "autoCutout", sampleAllLayers: false });
    const s = await boiteSelection();
    await deselectionner();
    if (!s || s.w < 4 || s.h < 4) return null;
    const b = bornes(l);
    const f = { x: (s.x - b.x) / b.w, y: (s.y - b.y) / b.h, w: s.w / b.w, h: s.h / b.h };
    if (f.w > 0.98 && f.h > 0.98) return null;          // rien de détecté de précis
    return f;
  } catch (e) { try { await deselectionner(); } catch (_) {} return null; }
}
// Place la photo pour couvrir la zone en gardant le sujet bien visible
async function cadrerPhoto(l, z, c) {
  await contenir(l, { x: 0, y: 0, w: c.W, h: c.H }, "center");
  const sujet = state.autoCadrage === false ? null : await analyserSujet(l);
  let b = bornes(l);
  const r = Math.max(z.w / b.w, z.h / b.h);
  await l.scale(r * 100, r * 100);
  b = bornes(l);
  let nx, ny;
  if (sujet) {
    const sW = sujet.w * b.w, sH = sujet.h * b.h, sx = b.x + (sujet.x + sujet.w / 2) * b.w, sTop = b.y + sujet.y * b.h;
    nx = b.x + (z.x + z.w / 2 - sx);
    // sujet trop haut pour la zone : on garde le haut (visage / toit) ; sinon centré un peu au-dessus du milieu
    ny = sH > z.h * 0.85 ? b.y + (z.y + z.h * 0.05 - sTop) : b.y + (z.y + z.h * 0.47 - (sTop + sH / 2));
    if (sW > z.w * 0.92) nx = b.x + (z.x + z.w / 2 - sx);
  } else {
    nx = z.x + (z.w - b.w) / 2; ny = z.y + (z.h - b.h) / 2;
  }
  nx = Math.min(z.x, Math.max(z.x + z.w - b.w, nx));    // la photo couvre toujours toute la zone
  ny = Math.min(z.y, Math.max(z.y + z.h - b.h, ny));
  await l.translate(nx - b.x, ny - b.y);
  return !!sujet;
}

async function contenir(l, z, align) {
  let b = bornes(l);
  const r = Math.min(z.w / b.w, z.h / b.h);
  await l.scale(r * 100, r * 100);
  b = bornes(l);
  const x = align === "center" ? z.x + (z.w - b.w) / 2 : align === "right" ? z.x + z.w - b.w : z.x;
  await l.translate(x - b.x, z.y + (z.h - b.h) / 2 - b.y);
}
async function ecreter() {
  await bp({ _obj: "groupEvent", _target: [{ _ref: "layer", _enum: "ordinal", _value: "targetEnum" }] });
}

/* =====================================================================
 * BLOCS DE MISE EN PAGE
 * ===================================================================== */

// Empile des textes dans une boîte : réduit si trop grand, centre verticalement.
async function pile(boite, elems, align = "center", valign = "middle") {
  const couches = [];
  for (const e of elems) {
    if (e.seulSi === false) continue;
    if (e.trait) {
      const l = await forme(e.nom, "rectangle", 0, 0, e.trait.w, e.trait.h, e.trait.couleur, 100, e.trait.h / 2);
      couches.push({ l, h: e.trait.h, w: e.trait.w, ecart: couches.length ? (e.ecart || 0) : 0, e });
      continue;
    }
    if (!e.texte || !String(e.texte).trim()) continue;
    const maxW = e.pastille ? boite.w - 2 * e.pastille.px : boite.w;
    const l = await texte(e.nom, e.texte, Object.assign({}, e, { align }));
    let b = await ajuster(l, maxW, null);
    if (e.remplir && b.w < boite.w * 0.98) {
      const r = Math.min(e.remplir, (boite.w * 0.98) / b.w);
      if (r > 1.01) { await l.scale(r * 100, r * 100); b = bornes(l); }
    }
    const px_ = e.pastille ? e.pastille.px : 0, py_ = e.pastille ? e.pastille.py : 0;
    couches.push({ l, h: b.h + 2 * py_, w: b.w + 2 * px_, ecart: couches.length ? (e.ecart || 0) : 0, e, px: px_, py: py_ });
  }
  if (!couches.length) return null;
  const somme = () => couches.reduce((s, c) => s + c.h + c.ecart, 0);
  let total = somme();
  if (total > boite.h) {
    const r = boite.h / total;
    for (const c of couches) {
      await c.l.scale(r * 100, r * 100);
      const b = bornes(c.l); c.px = (c.px || 0) * r; c.py = (c.py || 0) * r;
      c.h = b.h + 2 * c.py; c.w = b.w + 2 * c.px; c.ecart *= r;
    }
    total = somme();
  }
  let y = valign === "top" ? boite.y : valign === "bottom" ? boite.y + boite.h - total : boite.y + (boite.h - total) / 2;
  const y0 = y;
  for (const c of couches) {
    y += c.ecart;
    const x = align === "center" ? boite.x + (boite.w - c.w) / 2 : align === "right" ? boite.x + boite.w - c.w : boite.x;
    await placerA(c.l, x + (c.px || 0), y + (c.py || 0));
    y += c.h;
  }
  // Contrôle : chaque élément doit commencer sous le précédent (sinon on le décale vers le bas)
  let bas = null;
  for (const c of couches) {
    const b = bornes(c.l);
    const haut = b.y - (c.py || 0);
    if (bas !== null && haut < bas + c.ecart * 0.6) await c.l.translate(0, bas + c.ecart - haut);
    const b2 = bornes(c.l);
    bas = b2.y + b2.h + (c.py || 0);
  }
  // Si tout dépasse en bas, on remonte l'ensemble pour rester dans la boîte
  if (bas !== null && bas > boite.y + boite.h) {
    const dy = Math.max(-(bornes(couches[0].l).y - (couches[0].py || 0) - boite.y), boite.y + boite.h - bas);
    if (dy < 0) for (const c of couches) await c.l.translate(0, dy);
  }
  // Pastilles (dessinées une fois les positions définitives connues)
  for (const c of couches) {
    if (c.e && c.e.pastille) {
      const b = bornes(c.l);
      const p = await forme("Pastille " + c.e.nom, "rectangle", b.x - c.px, b.y - c.py, b.w + 2 * c.px, b.h + 2 * c.py, c.e.pastille.fond, 100, (b.h + 2 * c.py) / 2);
      try { await p.move(c.l, constants.ElementPlacement.PLACEAFTER); } catch (err) {}
    }
  }
  const premier = bornes(couches[0].l), dernier = bornes(couches[couches.length - 1].l);
  return { y0: premier.y - (couches[0].py || 0), y1: dernier.y + dernier.h + (couches[couches.length - 1].py || 0), couches };
}

function blocTextes(c, boite, coul, k = 1) {
  const { u, T, F } = c;
  const tK = 3.3 * u * k, tT = 12.5 * u * k, tD = 3.0 * u * k, tL = 3.3 * u * k;
  const dateFond = coul.date || coul.sous;
  return [
    { nom: "Surtitre", texte: (T.sousTitre || "").toUpperCase(), police: F.texteGras || F.titre, taille: tK, couleur: coul.sous, interlettre: 220 },
    { nom: "Titre", texte: couper(T.titre, carsPour(boite.w, tT, 0.6)), police: F.titre, taille: tT, interligne: tT * 0.96, couleur: coul.titre, remplir: 1.6, ecart: 1.4 * u * k },
    { nom: "Trait", trait: { w: 13 * u * k, h: Math.max(2, 0.9 * u * k), couleur: coul.sous }, ecart: 2.6 * u * k, seulSi: !!(T.details || T.dateLieu) },
    { nom: "Détails", texte: couper(T.details, carsPour(boite.w, tD, 0.5)), police: F.texte, taille: tD, interligne: tD * 1.45, couleur: coul.details, ecart: 2.4 * u * k },
    { nom: "Date et lieu", texte: T.dateLieu, police: F.texteGras || F.titre, taille: tL, interligne: tL * 1.2, couleur: contraste(dateFond),
      pastille: { fond: dateFond, px: 2.8 * u * k, py: 1.3 * u * k }, ecart: 3.2 * u * k }
  ];
}
async function badge(c, cx, cy, r, hexFond, hexTexte) {
  if (!c.T.badge) return;
  const fb = await forme("Badge", "ellipse", cx - r, cy - r, 2 * r, 2 * r, hexFond);
  if (state.moderne !== false) { try { await effetsSur(fb, { frameFX: fxContour("#FFFFFF", r * 0.07), dropShadow: fxOmbre("#000000", r * 0.08, r * 0.3, 35, 120) }); } catch (e) {} }
  const l = await texte("Texte du badge", couper(c.T.badge, 7),
    { police: c.F.titre, taille: r * 0.62, interligne: r * 0.58, couleur: hexTexte });
  await l.rotate(-8);
  await ajuster(l, r * 1.45, r * 1.25);
  await centrer(l, cx, cy);
}

async function logo(z, align) {
  if (!state.logo) return;
  const l = await placerImage(state.logo, "Logo");
  const mode = state.fondLogo || "auto";
  if (mode === "aucun") { await contenir(l, z, align); return; }
  const b0 = bornes(l), ratio = b0.w / b0.h;
  const formeFond = mode === "auto" ? (ratio > 0.68 && ratio < 1.5 ? "cercle" : "rect") : mode;
  const posX = (w) => (align === "center" ? z.x + (z.w - w) / 2 : align === "right" ? z.x + z.w - w : z.x);
  let fond;
  if (formeFond === "cercle") {
    const D = Math.min(z.w, z.h * 1.6);
    const x = posX(D), y = z.y;
    const cote = D * 0.66;
    await contenir(l, { x: x + (D - cote) / 2, y: y + (D - cote) / 2, w: cote, h: cote }, "center");
    fond = await forme("Fond du logo", "ellipse", x, y, D, D, "#FFFFFF");
  } else {
    const p = z.h * 0.16;
    await contenir(l, { x: z.x + p, y: z.y + p, w: z.w - 2 * p, h: z.h - 2 * p }, "center");
    const lb = bornes(l);
    const w = Math.min(z.w, lb.w + 2.6 * p), h = Math.min(z.h, lb.h + 2 * p);
    const x = posX(w), y = z.y + (z.h - h) / 2;
    await l.translate(x + (w - lb.w) / 2 - lb.x, y + (h - lb.h) / 2 - lb.y);
    fond = await forme("Fond du logo", "rectangle", x, y, w, h, "#FFFFFF", 100, Math.min(h * 0.28, z.h * 0.3));
  }
  try { await fond.move(l, constants.ElementPlacement.PLACEAFTER); } catch (e) {}
  try {
    const fb = bornes(fond);
    await effetsSur(fond, { dropShadow: fxOmbre("#000000", fb.h * 0.04, fb.h * 0.12, 28, 120) });
  } catch (e) {}
  try { await grouper([fond.id, l.id], "Logo"); } catch (e) {}
}

// Forme de cadre choisie par le client (ou celle du modèle si « auto »)
function cadreChoisi(defType, defRayon, z) {
  const f = state.formeCadres || "auto";
  if (f === "cercle") return ["ellipse", 0, true];
  if (f === "carre") return ["rectangle", Math.min(z.w, z.h) * 0.12, false];
  if (f === "rect") return ["rectangle", Math.min(z.w, z.h) * 0.03, false];
  return [defType, defRayon, false];
}
async function zonePhoto(c, z, type, rayon, hexVide, encadre) {
  const [t, r, carre] = cadreChoisi(type, rayon, z);
  if (carre && Math.abs(z.w - z.h) > 2) { const d = Math.min(z.w, z.h); z = { x: z.x + (z.w - d) / 2, y: z.y + (z.h - d) / 2, w: d, h: d }; }
  const base = await forme("Zone photo", t, z.x, z.y, z.w, z.h, hexVide, 100, r);
  if (encadre !== false && state.moderne !== false && !(z.x <= 1 && z.y <= 1) && !(z.w >= c.W - 1)) {
    try { await effetsSur(base, { frameFX: fxContour("#FFFFFF", Math.max(2, Math.min(z.w, z.h) * 0.022)), dropShadow: fxOmbre("#000000", c.u * 0.8, c.u * 2.5, 35, 120) }); } catch (e) {}
    await selectionnerCalque(base.id);
  }
  if (state.photo) {
    const p = await placerImage(state.photo, "Photo");
    await cadrerPhoto(p, z, c);
    await ecreter();
  } else {
    const l = await texte("Indication (à supprimer)", "PLACEZ VOTRE PHOTO ICI",
      { police: c.F.titre, taille: 4 * c.u, couleur: "#FFFFFF", interlettre: 60, opacite: 45 });
    await ajuster(l, z.w * 0.8, z.h * 0.5);
    await centrer(l, z.x + z.w / 2, z.y + z.h / 2);
    await ecreter();
  }
  return z;
}

// Galerie de photos de produits (jusqu'à 4) dans des cadres
async function galerie(c, zone, defForme) {
  const imgs = (state.produits || []).slice(0, 4);
  if (!imgs.length) return null;
  const n = imgs.length, gap = c.u * 2.5;
  const f = state.formeCadres && state.formeCadres !== "auto" ? state.formeCadres : (defForme || "carre");
  const cell = Math.min((zone.w - gap * (n - 1)) / n, zone.h);
  const hCell = f === "rect" ? cell * 0.75 : cell;
  const total = cell * n + gap * (n - 1);
  let x = zone.x + (zone.w - total) / 2;
  const y = zone.y + (zone.h - hCell) / 2;
  const ids = [];
  for (let i = 0; i < n; i++) {
    const z = { x, y, w: cell, h: hCell };
    const base = await forme("Cadre produit " + (i + 1), f === "cercle" ? "ellipse" : "rectangle", z.x, z.y, z.w, z.h, "#FFFFFF", 100, f === "carre" ? cell * 0.16 : f === "rect" ? cell * 0.05 : 0);
    try { await effetsSur(base, { frameFX: fxContour("#FFFFFF", Math.max(2, cell * 0.035)), dropShadow: fxOmbre("#000000", cell * 0.04, cell * 0.12, 35, 120) }); } catch (e) {}
    await selectionnerCalque(base.id);
    const p = await placerImage(imgs[i], "Produit " + (i + 1));
    await cadrerPhoto(p, z, c);
    await ecreter();
    ids.push(base.id, p.id);
    x += cell + gap;
  }
  try { await grouper(ids, "Galerie produits"); } catch (e) {}
  return { y0: y, y1: y + hCell };
}

async function barreContact(c, x, y, w, h, hexFond, hexTexte) {
  if (state.moderne === false) {
    await forme("Bandeau contact", "rectangle", x, y, w, h, hexFond);
  } else {
    await forme("Bandeau contact", "rectangle", x, y, w, h, nuance(hexFond, -0.55));
    const m = h * 0.16;
    await forme("Bandeau contact (pastille)", "rectangle", x + 4 * c.u, y + m, w - 8 * c.u, h - 2 * m, hexFond, 100, (h - 2 * m) / 2);
    hexTexte = contraste(hexFond);
  }
  await pile({ x: x + 7 * c.u, y: y + h * 0.2, w: w - 14 * c.u, h: h * 0.6 },
    [{ nom: "Contact", texte: c.T.contact, police: c.F.texteGras || c.F.titre, taille: h * 0.38, couleur: hexTexte, interlettre: 30 }],
    "center", "middle");
}

function hauteurBarre(c) {
  return c.T.contact ? Math.round(Math.max(9 * c.u, c.H * 0.07)) : 0;
}

/* =====================================================================
 * MODÈLES
 * ===================================================================== */

// 1. IMPACT — grand cercle d'accent, texte aligné à gauche, bandeau contact
async function modeleImpact(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.fond);
  if (state.photo) {
    const p = await placerImage(state.photo, "Photo de fond");
    await cadrerPhoto(p, { x: 0, y: 0, w: W, h: H }, c);
    await forme("Voile sombre", "rectangle", 0, 0, W, H, P.sombre, 62);
  }
  const m = Math.min(W, H);
  const r = m * 0.40;
  const cx = paysage ? W * 0.93 : W * 0.95;
  const cy = paysage ? H * 0.08 : H * 0.03;
  await forme("Décor - grand cercle", "ellipse", cx - r, cy - r, 2 * r, 2 * r, P.accent, state.photo ? 90 : 100);
  const r2 = m * 0.22;
  await forme("Décor - cercle bas", "ellipse", -r2 * 0.45, H - r2 * 1.3, 2 * r2, 2 * r2, P.texte, 12);

  const barH = hauteurBarre(c);
  const top = paysage ? 27 * u : H * 0.32;
  await forme("Décor - trait", "rectangle", 8 * u, top - 4 * u, 14 * u, 1.4 * u, P.accent);
  await logo({ x: 7 * u, y: 7 * u, w: 26 * u, h: 12 * u }, "left");

  const boite = { x: 8 * u, y: top, w: paysage ? W * 0.6 : W - 16 * u, h: H - barH - 6 * u - top };
  await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }), "left", "middle");

  await badge(c, cx - r * 0.35, cy + r * 0.45, paysage ? 13 * u : 12 * u, P.sombre, P.accent);
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}

// 2. PHOTO — grande photo en haut (ou à gauche), panneau coloré pour le texte
async function modelePhoto(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.fond);
  const z = paysage ? { x: 0, y: 0, w: Math.round(W * 0.5), h: H } : { x: 0, y: 0, w: W, h: Math.round(H * 0.52) };
  await zonePhoto(c, z, "rectangle", 0, P.sombre);
  const ep = 1.4 * u;
  if (paysage) await forme("Liseré", "rectangle", z.w - ep / 2, 0, ep, H, P.accent);
  else await forme("Liseré", "rectangle", 0, z.h - ep / 2, W, ep, P.accent);
  await logo({ x: 5 * u, y: 5 * u, w: 24 * u, h: 11 * u }, "left");

  const barH = hauteurBarre(c);
  const boite = paysage
    ? { x: z.w + 6 * u, y: 8 * u, w: W - z.w - 12 * u, h: H - barH - 14 * u }
    : { x: 7 * u, y: z.h + 7 * u, w: W - 14 * u, h: H - z.h - barH - 11 * u };
  await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, paysage ? 0.9 : 0.85), "center", "middle");

  await badge(c, z.w - 16 * u, 16 * u, 11 * u, P.accent, P.sombre);
  if (barH) await barreContact(c, paysage ? z.w : 0, H - barH, paysage ? W - z.w : W, barH, P.accent, P.sombre);
}

// 3. ÉPURÉ — fond clair, barre d'accent, texte à gauche, photo arrondie
async function modeleEpure(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.texte);
  await logo({ x: 7 * u, y: 7 * u, w: 26 * u, h: 12 * u }, "left");

  let boite;
  if (paysage) {
    if (state.photo) {
      const z = { x: Math.round(W * 0.55), y: 7 * u, w: Math.round(W * 0.45 - 7 * u), h: H - 14 * u };
      await zonePhoto(c, z, "rectangle", 3 * u, P.fond);
      boite = { x: 12 * u, y: 24 * u, w: W * 0.55 - 20 * u, h: H - 40 * u };
    } else {
      boite = { x: 12 * u, y: 24 * u, w: W * 0.75, h: H - 40 * u };
    }
  } else {
    if (state.photo) {
      const z = { x: 7 * u, y: Math.round(H * 0.58), w: W - 14 * u, h: Math.round(H * 0.30) };
      await zonePhoto(c, z, "rectangle", 3 * u, P.fond);
      boite = { x: 12 * u, y: 24 * u, w: W - 20 * u, h: H * 0.58 - 30 * u };
    } else {
      boite = { x: 12 * u, y: 26 * u, w: W - 20 * u, h: H * 0.88 - 30 * u };
    }
  }
  const res = await pile(boite, blocTextes(c, boite, { titre: P.sombre, sous: P.fond, details: P.sombre, date: P.fond }), "left", "middle");
  if (res) await forme("Barre d'accent", "rectangle", 7 * u, res.y0, 1.3 * u, res.y1 - res.y0, P.accent);

  if (c.T.contact) {
    const zc = paysage ? { x: 7 * u, y: H - 13 * u, w: W * 0.5, h: 7 * u } : { x: 7 * u, y: H * 0.91, w: W - 14 * u, h: H * 0.05 };
    await pile(zc, [{ nom: "Contact", texte: c.T.contact, police: c.F.titre, taille: zc.h * 0.7, couleur: P.sombre, interlettre: 20 }], "left", "middle");
  }
  await badge(c, W - 16 * u, 16 * u, 10 * u, P.fond, P.texte);
}

// 4. PROMO — grand cercle (photo ou offre), fond sombre, bandeau contact
async function modelePromo(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.sombre);
  await forme("Décor - point 1", "ellipse", W * 0.07, H * 0.05, 6 * u, 6 * u, P.accent, 70);
  await forme("Décor - point 2", "ellipse", W * 0.88, H * 0.45, 4 * u, 4 * u, P.fond, 80);
  await forme("Décor - anneau", "ellipse", W * 0.80, H * 0.04, 10 * u, 10 * u, P.texte, 10);

  const r = paysage ? Math.min(H * 0.36, W * 0.22) : Math.min(W * 0.34, H * 0.2);
  const cx = paysage ? W * 0.27 : W / 2;
  const cy = paysage ? H * 0.47 : r * 1.07 + 6 * u;
  await forme("Cercle - contour", "ellipse", cx - r * 1.07, cy - r * 1.07, r * 2.14, r * 2.14, P.accent);
  const zc = { x: cx - r, y: cy - r, w: 2 * r, h: 2 * r };

  if (state.photo) {
    await zonePhoto(c, zc, "ellipse", 0, P.fond);
  } else {
    await forme("Cercle", "ellipse", zc.x, zc.y, zc.w, zc.h, P.fond);
    const l = await texte("Texte du cercle", couper(c.T.badge || "PROMO", 8),
      { police: c.F.titre, taille: r * 0.6, interligne: r * 0.55, couleur: P.texte });
    await ajuster(l, r * 1.5, r * 1.2);
    await centrer(l, cx, cy);
  }
  await logo({ x: 6 * u, y: 6 * u, w: 22 * u, h: 10 * u }, "left");

  const barH = hauteurBarre(c);
  const top = cy + r * 1.07 + 5 * u;
  const boite = paysage
    ? { x: W * 0.53, y: 9 * u, w: W * 0.47 - 8 * u, h: H - barH - 15 * u }
    : { x: 7 * u, y: top, w: W - 14 * u, h: H - top - barH - 5 * u };
  await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }), "center", "middle");

  if (state.photo) await badge(c, cx + r * 0.72, cy + r * 0.68, r * 0.34, P.accent, P.sombre);
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}


/* ---------- Modèles v1.2 ---------- */
function sansDate(c, boite, coul, k) { return blocTextes(c, boite, coul, k).filter((e) => e.nom !== "Date et lieu"); }

async function effetsSur(l, fx) {
  await selectionnerCalque(l.id);
  await ecrireEffets(Object.assign({ _obj: "layerEffects", scale: pct(100) }, fx));
}

async function bandeau(c, x, y, w, h, hexFond, hexTexte, txt, nom) {
  await forme(nom, "rectangle", x, y, w, h, hexFond);
  await pile({ x: x + 4 * c.u, y: y + h * 0.18, w: w - 8 * c.u, h: h * 0.64 },
    [{ nom: nom + " - texte", texte: txt, police: c.F.titre, taille: h * 0.45, couleur: hexTexte, interlettre: 40 }], "center", "middle");
}

// 5. SOIRÉE — fond sombre, halos colorés, titre lumineux, bandeau date
async function modeleSoiree(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.sombre);
  if (state.photo) {
    const p = await placerImage(state.photo, "Photo de fond");
    await cadrerPhoto(p, { x: 0, y: 0, w: W, h: H }, c);
    await forme("Voile sombre", "rectangle", 0, 0, W, H, P.sombre, 70);
  }
  const m = Math.min(W, H);
  await forme("Halo 1", "ellipse", -m * 0.25, -m * 0.2, m * 0.9, m * 0.9, P.fond, 35);
  await forme("Halo 2", "ellipse", W - m * 0.6, H - m * 0.75, m * 0.8, m * 0.8, P.accent, 22);
  await forme("Anneau", "ellipse", W * 0.62, H * 0.08, m * 0.22, m * 0.22, P.texte, 10);
  await logo({ x: 6 * u, y: 6 * u, w: 24 * u, h: 10 * u }, "left");
  const barH = hauteurBarre(c);
  const bandH = c.T.dateLieu ? Math.round(10 * u) : 0;
  const top = paysage ? 16 * u : H * 0.2;
  const bas = H - barH - (bandH ? bandH + 8 * u : 5 * u);
  const boite = { x: 8 * u, y: top, w: W - 16 * u, h: bas - top - 3 * u };
  const res = await pile(boite, sansDate(c, boite, { titre: P.texte, sous: P.accent, details: P.texte }), "center", "middle");
  const t = res && res.couches.find((x) => x.l.name === "Titre");
  if (t) { try { await effetsSur(t.l, { outerGlow: effetLueur("outerGlow", P.fond, Math.round(4 * u), 85) }); } catch (e) {} }
  if (bandH) await bandeau(c, 0, H - barH - bandH - 4 * u, W, bandH, P.accent, P.sombre, c.T.dateLieu.toUpperCase(), "Bandeau date");
  await badge(c, W - 15 * u, paysage ? 18 * u : H * 0.14, 11 * u, P.fond, P.texte);
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.texte, P.sombre);
}

// 6. CULTE — rayons de lumière, photo ronde, texte centré entre deux filets
async function modeleCulte(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.sombre);
  const m = Math.max(W, H), lx = W / 2, ly = paysage ? H * 0.1 : H * 0.08;
  for (const [k, op] of [[1.2, 6], [0.85, 8], [0.58, 10], [0.34, 14]]) {
    await forme("Lumière", "ellipse", lx - m * k / 2, ly - m * k / 2, m * k, m * k, P.accent, op);
  }
  await logo({ x: W / 2 - 12 * u, y: 3 * u, w: 24 * u, h: 8 * u }, "center");
  let top, boite;
  const barH = hauteurBarre(c);
  if (state.photo) {
    const r = paysage ? H * 0.3 : Math.min(W * 0.2, H * 0.15);
    const pcx = paysage ? W * 0.27 : W / 2;
    const pcy = paysage ? H * 0.5 : 13 * u + r * 1.06;
    await forme("Cercle - contour", "ellipse", pcx - r * 1.06, pcy - r * 1.06, r * 2.12, r * 2.12, P.accent);
    await zonePhoto(c, { x: pcx - r, y: pcy - r, w: 2 * r, h: 2 * r }, "ellipse", 0, P.fond);
    top = paysage ? 14 * u : pcy + r * 1.06 + 7 * u;
    boite = paysage ? { x: W * 0.52, y: top, w: W * 0.44, h: H - barH - top - 8 * u } : { x: 9 * u, y: top, w: W - 18 * u, h: H - barH - top - 8 * u };
  } else {
    top = paysage ? 16 * u : H * 0.24;
    boite = { x: 9 * u, y: top, w: W - 18 * u, h: H - barH - top - 8 * u };
  }
  const res = await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, 0.9), "center", "middle");
  if (res) {
    const cx = boite.x + boite.w / 2;
    await forme("Filet haut", "rectangle", cx - 10 * u, res.y0 - 4 * u, 20 * u, 0.5 * u, P.accent);
    await forme("Filet bas", "rectangle", cx - 10 * u, res.y1 + 3.5 * u, 20 * u, 0.5 * u, P.accent);
  }
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}

// 7. IMMOBILIER — grande photo, étiquette de prix, texte aligné à gauche
async function modeleImmo(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.texte);
  const z = paysage ? { x: 0, y: 0, w: Math.round(W * 0.55), h: H } : { x: 0, y: 0, w: W, h: Math.round(H * 0.5) };
  await zonePhoto(c, z, "rectangle", 0, P.sombre);
  await logo({ x: 5 * u, y: 5 * u, w: 24 * u, h: 10 * u }, "left");
  if (c.T.badge) {
    const ew = paysage ? 34 * u : 46 * u, eh = 12 * u;
    const ex = paysage ? z.w - ew / 2 : W - ew - 6 * u, ey = paysage ? H * 0.12 : z.h - eh / 2;
    await forme("Étiquette prix", "rectangle", ex, ey, ew, eh, P.accent, 100, 2 * u);
    await pile({ x: ex + 2 * u, y: ey + eh * 0.15, w: ew - 4 * u, h: eh * 0.7 },
      [{ nom: "Prix", texte: c.T.badge, police: c.F.titre, taille: eh * 0.5, couleur: P.sombre }], "center", "middle");
  }
  const barH = hauteurBarre(c);
  const boite = paysage ? { x: z.w + 7 * u, y: 24 * u, w: W - z.w - 13 * u, h: H - barH - 32 * u }
                        : { x: 9 * u, y: z.h + 10 * u, w: W - 16 * u, h: H - z.h - barH - 14 * u };
  const res = await pile(boite, blocTextes(c, boite, { titre: P.sombre, sous: P.fond, details: P.sombre, date: P.fond }, 0.85), "left", "middle");
  if (res) await forme("Barre d'accent", "rectangle", boite.x - 3.5 * u, res.y0, 1.2 * u, res.y1 - res.y0, P.fond);
  if (barH) await barreContact(c, paysage ? z.w : 0, H - barH, paysage ? W - z.w : W, barH, P.fond, P.texte);
}

// 8. CHANTIER — bandes de sécurité, photo, texte à gauche
async function rayures(c, x, y, w, h, hexFond, hexRayure) {
  await forme("Bande chantier", "rectangle", x, y, w, h, hexFond);
  const ep = h * 0.9, pas = ep * 2;
  for (let xi = x - h * 2; xi < x + w + h; xi += pas) {
    const l = await forme("Rayure", "rectangle", xi, y - h, ep * 0.7, h * 3, hexRayure);
    await l.rotate(35);
    await ecreter();
  }
}
async function modeleChantier(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.sombre);
  const bh = Math.round(5 * u);
  await rayures(c, 0, 0, W, bh, P.accent, P.sombre);
  const z = paysage ? { x: Math.round(W * 0.5), y: bh, w: Math.round(W * 0.5), h: H - bh } : { x: 0, y: bh, w: W, h: Math.round(H * 0.42) };
  await zonePhoto(c, z, "rectangle", 0, P.fond);
  await logo({ x: 6 * u, y: bh + 4 * u, w: 24 * u, h: 10 * u }, "left");
  const barH = hauteurBarre(c);
  const top = paysage ? bh + 20 * u : z.y + z.h + 8 * u;
  const boite = { x: 7 * u, y: top, w: (paysage ? W * 0.5 : W) - 14 * u, h: H - barH - bh - top - 6 * u };
  await forme("Trait", "rectangle", boite.x, top - 3 * u, 16 * u, 1.2 * u, P.accent);
  await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, 0.9), "left", "middle");
  await badge(c, paysage ? z.x : W - 16 * u, paysage ? H * 0.5 : z.y + z.h, 11 * u, P.accent, P.sombre);
  await rayures(c, 0, H - barH - bh, W, bh, P.accent, P.sombre);
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}

// 9. PRODUITS — photo vedette encadrée, prix, galerie de produits
async function modeleProduits(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.fond);
  const m = Math.min(W, H);
  await forme("Décor - cercle", "ellipse", W - m * 0.45, -m * 0.2, m * 0.7, m * 0.7, P.accent, 30);
  await forme("Décor - cercle bas", "ellipse", -m * 0.25, H - m * 0.4, m * 0.6, m * 0.6, P.texte, 10);
  await logo({ x: 6 * u, y: 5 * u, w: 24 * u, h: 10 * u }, "left");
  const barH = hauteurBarre(c);
  const aGalerie = (state.produits || []).length > 0;
  if (paysage) {
    const hero = { x: 6 * u, y: 18 * u, w: W * 0.42, h: H - barH - 24 * u };
    const z = await zonePhoto(c, hero, "rectangle", 3 * u, P.sombre);
    if (c.T.badge) await badge(c, z.x + z.w - 2 * u, z.y + 4 * u, 11 * u, P.accent, contraste(P.accent));
    const droite = { x: W * 0.5, y: 14 * u, w: W * 0.46, h: H - barH - 20 * u };
    const hG = aGalerie ? Math.min(20 * u, droite.h * 0.32) : 0;
    await pile({ x: droite.x, y: droite.y, w: droite.w, h: droite.h - hG - 4 * u },
      blocTextes(c, droite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, 0.85), "left", "middle");
    if (aGalerie) await galerie(c, { x: droite.x, y: droite.y + droite.h - hG, w: droite.w, h: hG }, "carre");
  } else {
    const hero = { x: 7 * u, y: 17 * u, w: W - 14 * u, h: H * (aGalerie ? 0.34 : 0.42) };
    const z = await zonePhoto(c, hero, "rectangle", 3 * u, P.sombre);
    if (c.T.badge) await badge(c, z.x + z.w - 6 * u, z.y + z.h - 2 * u, 12 * u, P.accent, contraste(P.accent));
    let yTxt = z.y + z.h + 6 * u;
    if (aGalerie) {
      const hG = Math.min(20 * u, (W - 14 * u) / 4.4);
      const g = await galerie(c, { x: 7 * u, y: yTxt, w: W - 14 * u, h: hG }, "carre");
      yTxt = (g ? g.y1 : yTxt) + 5 * u;
    }
    const boite = { x: 8 * u, y: yTxt, w: W - 16 * u, h: H - barH - yTxt - 4 * u };
    await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, 0.85), "center", "middle");
  }
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}

// 10. MODERNE — grands cercles en dégradé, photo ronde, carte « verre »
async function modeleModerne(c) {
  const { W, H, u, P, paysage } = c;
  await fond(P.fond);
  const m = Math.min(W, H);
  await forme("Décor - grand cercle", "ellipse", W - m * 0.55, -m * 0.3, m * 0.95, m * 0.95, P.accent, 85);
  await forme("Décor - cercle", "ellipse", -m * 0.3, H * 0.55, m * 0.7, m * 0.7, P.sombre, 55);
  await forme("Décor - anneau", "ellipse", W * 0.08, H * 0.1, m * 0.12, m * 0.12, P.texte, 18);
  const barH = hauteurBarre(c);
  // photo ronde à droite / en haut
  const r = paysage ? H * 0.32 : W * 0.27;
  const pc = paysage ? [W * 0.74, H * 0.45] : [W * 0.66, 15 * u + r];
  if (state.photo) await zonePhoto(c, { x: pc[0] - r, y: pc[1] - r, w: 2 * r, h: 2 * r }, "ellipse", 0, P.sombre);
  await logo({ x: 6 * u, y: 5 * u, w: 24 * u, h: 10 * u }, "left");
  if (c.T.badge) await badge(c, pc[0] - r * 0.78, pc[1] + r * 0.62, 10 * u, P.texte, P.fond);
  // carte « verre » pour le texte
  const carte = paysage ? { x: 6 * u, y: 16 * u, w: W * 0.5, h: H - barH - 22 * u }
                        : { x: 6 * u, y: (state.photo ? pc[1] + r + 5 * u : 20 * u), w: W - 12 * u, h: 0 };
  if (!paysage) carte.h = H - barH - carte.y - 5 * u;
  const vitre = await forme("Carte verre", "rectangle", carte.x, carte.y, carte.w, carte.h, "#FFFFFF", 12, 3.5 * u);
  try { await effetsSur(vitre, { frameFX: Object.assign(fxContour("#FFFFFF", Math.max(1, u * 0.25)), { opacity: pct(45) }) }); } catch (e) {}
  const boite = { x: carte.x + 6 * u, y: carte.y + 5 * u, w: carte.w - 12 * u, h: carte.h - 10 * u };
  await pile(boite, blocTextes(c, boite, { titre: P.texte, sous: P.accent, details: P.texte, date: P.accent }, paysage ? 0.85 : 0.9), "left", "middle");
  if (barH) await barreContact(c, 0, H - barH, W, barH, P.accent, P.sombre);
}

const MODELES = { impact: modeleImpact, photo: modelePhoto, epure: modeleEpure, promo: modelePromo,
  soiree: modeleSoiree, culte: modeleCulte, immo: modeleImmo, chantier: modeleChantier,
  produits: modeleProduits, moderne: modeleModerne };

async function filigrane(c) {
  const { W, H, u } = c;
  const l = await texte("Filigrane - version d'essai", "VERSION D'ESSAI\rAffiche Minute",
    { police: c.F.titre, taille: 9 * u, interligne: 10 * u, couleur: "#FFFFFF", opacite: 40 });
  await l.rotate(-30);
  await ajuster(l, W * 0.9, H * 0.9);
  await centrer(l, W / 2, H / 2);
  const l2 = await texte("Filigrane - mention", "Version d'essai · Affiche Minute · Mr Doamba",
    { police: c.F.texte, taille: 2.4 * u, couleur: "#FFFFFF", opacite: 70 });
  await ajuster(l2, W * 0.9, null);
  await centrer(l2, W / 2, 3 * u);
}

/* ---------- Styles de polices (accords titre + texte) ---------- */
const STYLES_POLICES = {
  moderne: { nom: "Moderne", titre: ["Montserrat-ExtraBold", "Montserrat-Black", "Poppins-ExtraBold", "Poppins-Bold", "SegoeUI-Black", "SegoeUI-Bold", "Arial-BoldMT"],
    texte: ["Poppins-Regular", "Montserrat-Regular", "SegoeUI", "ArialMT"], gras: ["Poppins-SemiBold", "Montserrat-SemiBold", "SegoeUI-Semibold", "SegoeUI-Bold", "Arial-BoldMT"] },
  impact: { nom: "Impact", titre: ["Anton-Regular", "BebasNeue-Regular", "BebasNeue", "LeagueGothic-Regular", "Impact", "Arial-Black"],
    texte: ["Montserrat-Medium", "Poppins-Regular", "SegoeUI", "ArialMT"], gras: ["Montserrat-Bold", "Poppins-SemiBold", "SegoeUI-Semibold", "Arial-BoldMT"] },
  elegant: { nom: "Élégant", titre: ["PlayfairDisplay-Bold", "PlayfairDisplay-Black", "DMSerifDisplay-Regular", "Georgia-Bold", "Cambria-Bold", "TimesNewRomanPS-BoldMT"],
    texte: ["Lato-Regular", "Raleway-Regular", "Georgia", "Cambria", "SegoeUI-Light"], gras: ["Lato-Bold", "Raleway-SemiBold", "Georgia-Bold", "SegoeUI-Semibold"] },
  fun: { nom: "Fun / Enfants", titre: ["LuckiestGuy-Regular", "Chewy-Regular", "Fredoka-Bold", "FredokaOne-Regular", "ComicSansMS-Bold", "SegoePrint-Bold"],
    texte: ["Fredoka-Regular", "Nunito-Regular", "ComicSansMS", "SegoePrint"], gras: ["Fredoka-SemiBold", "Nunito-Bold", "ComicSansMS-Bold", "SegoePrint-Bold"] },
  eglise: { nom: "Église / Spirituel", titre: ["Cinzel-Bold", "Cinzel-Black", "TrajanPro-Bold", "TrajanPro3-Bold", "Georgia-Bold", "Cambria-Bold"],
    texte: ["Lora-Regular", "Georgia", "MinionPro-Regular", "Cambria"], gras: ["Lora-Bold", "Cinzel-Regular", "Georgia-Bold", "Cambria-Bold"] },
  script: { nom: "Script / Mariage", titre: ["GreatVibes-Regular", "Pacifico-Regular", "DancingScript-Bold", "SegoeScript-Bold", "LucidaHandwriting-Italic", "BrushScriptMT"],
    texte: ["Poppins-Light", "Lato-Light", "SegoeUI-Light", "SegoeUI"], gras: ["Poppins-Medium", "Lato-Bold", "SegoeUI-Semibold"] },
  tech: { nom: "Tech / Pro", titre: ["Orbitron-Bold", "Rajdhani-Bold", "Bahnschrift-Bold", "Bahnschrift", "SegoeUI-Bold", "Arial-BoldMT"],
    texte: ["Rajdhani-Medium", "Bahnschrift-Light", "SegoeUI", "Calibri"], gras: ["Rajdhani-SemiBold", "Bahnschrift-SemiBold", "SegoeUI-Semibold", "Calibri-Bold"] }
};
const POLICES_MODELE = { impact: "impact", photo: "moderne", epure: "elegant", promo: "impact", soiree: "impact", culte: "eglise",
  immo: "elegant", chantier: "tech", produits: "moderne", moderne: "moderne" };
let POLICES_INSTALLEES = null;
function policeInstallee(ps) {
  if (!POLICES_INSTALLEES) POLICES_INSTALLEES = new Set(listePolices().map((f) => f.ps));
  return POLICES_INSTALLEES.has(ps);
}
function resoudrePolices(style, defT, defX) {
  const S = STYLES_POLICES[style];
  if (!S) return { titre: defT, texte: defX, texteGras: defT, nom: "Personnalisé" };
  const pick = (l, d) => l.find(policeInstallee) || d;
  return { titre: pick(S.titre, defT), texte: pick(S.texte, defX), texteGras: pick(S.gras, pick(S.titre, defT)), nom: S.nom };
}

/* =====================================================================
 * GÉNÉRATION
 * ===================================================================== */
function lireFormulaire() {
  const g = (id) => ($(id).value || "").trim();
  let titre = g("titre") || "VOTRE TITRE ICI";
  if ($("majuscules").checked) titre = titre.toUpperCase();
  const coul = (id, def) => (hexValide(g(id)) ? "#" + g(id).replace("#", "") : def);
  const p0 = PALETTES[state.palette] || PALETTES[0];
  return {
    format: $("format").value || "a4",
    T: { titre, sousTitre: g("sousTitre"), details: g("details"), dateLieu: g("dateLieu"), badge: g("badge"), contact: g("contact") },
    P: { fond: coul("cFond", p0.fond), accent: coul("cAccent", p0.accent), texte: coul("cTexte", p0.texte), sombre: coul("cSombre", p0.sombre) },
    F: (() => {
      const defT = $("policeTitre").value || "Arial-BoldMT", defX = $("policeTexte").value || "ArialMT";
      let st = ($("stylePolice") && $("stylePolice").value) || "auto";
      if (st === "auto") st = POLICES_MODELE[state.modele] || "moderne";
      return resoudrePolices(st, defT, defX);
    })()
  };
}

async function generer() {
  const btn = $("btnGenerer");
  const v = lireFormulaire();
  const fmt = FORMATS[v.format] || FORMATS.a4;
  const licencie = verifierCle(lsGet("afm_cle", ""));
  state.fondLogo = ($("fondLogo") && $("fondLogo").value) || "auto";
  state.moderne = !$("rendu") || $("rendu").value !== "aplat";
  state.formeCadres = ($("formeCadres") && $("formeCadres").value) || "auto";
  state.titre3D = ($("titre3D") && $("titre3D").value) || "aucun";
  state.autoCadrage = !$("autoCadrage") || $("autoCadrage").checked;
  if ($("memoriser").checked) sauverReglages();

  statut("Génération en cours…");
  btn.disabled = true;
  try {
    await core.executeAsModal(async (ctx) => {
      const doc = await app.documents.add({
        width: fmt.w, height: fmt.h, resolution: 72,
        mode: constants.NewDocumentMode.RGB, fill: constants.DocumentFill.WHITE,
        name: "Affiche minute - " + v.T.titre.substr(0, 24)
      });
      let hid = null;
      try { hid = await ctx.hostControl.suspendHistory({ documentID: doc.id, name: "Affiche Minute" }); } catch (e) {}
      try {
        const W = fmt.w, H = fmt.h;
        const c = { W, H, u: Math.min(W, H) / 100, paysage: W > H * 1.2, T: v.T, P: v.P, F: v.F };
        await MODELES[state.modele](c);
        try { await titreEn3D(c); } catch (e) { console.error(e); }
        if (!licencie) await filigrane(c);
        if (fmt.print) await doc.resizeImage(undefined, undefined, 300, constants.ResampleMethod.NONE);
      } finally {
        if (hid !== null) { try { await ctx.hostControl.resumeHistory(hid); } catch (e) {} }
      }
    }, { commandName: "Affiche Minute - génération" });
    statut(licencie ? "Affiche prête ✓ Tous les calques sont modifiables." : "Affiche prête ✓ (version d'essai avec filigrane)", "ok");
  } catch (e) {
    console.error(e);
    statut("Erreur : " + (e && e.message ? e.message : e), "erreur");
  } finally {
    btn.disabled = false;
  }
}

function statut(msg, type) {
  const s = $("statut");
  s.textContent = msg;
  s.className = "msg" + (type ? " " + type : "");
}

/* =====================================================================
 * INTERFACE
 * ===================================================================== */
function majNotePolice() {
  try {
    let st = $("stylePolice").value;
    if (st === "auto") st = POLICES_MODELE[state.modele] || "moderne";
    const F = resoudrePolices(st, $("policeTitre").value, $("policeTexte").value);
    $("notePolice").textContent = "Titres : " + F.titre + " · Textes : " + F.texte + (STYLES_POLICES[st] ? " (style " + STYLES_POLICES[st].nom + ")" : "");
  } catch (e) {}
}
function choisirModele(m) {
  state.modele = MODELES[m] ? m : "impact";
  setTimeout(majNotePolice, 0);
  document.querySelectorAll(".tuile").forEach((t) => {
    t.className = "tuile" + (t.getAttribute("data-m") === state.modele ? " actif" : "");
  });
}

function remplirFormats() {
  const sel = $("format");
  Object.keys(FORMATS).forEach((k) => {
    const o = document.createElement("option");
    o.value = k; o.textContent = FORMATS[k].label;
    sel.appendChild(o);
  });
}

function majPastilles() {
  [["cFond", "vFond"], ["cAccent", "vAccent"], ["cTexte", "vTexte"], ["cSombre", "vSombre"]].forEach(([i, v]) => {
    const val = $(i).value.trim();
    if (hexValide(val)) $(v).style.backgroundColor = "#" + val.replace("#", "");
  });
}

function choisirPalette(i) {
  state.palette = i;
  const p = PALETTES[i];
  $("cFond").value = p.fond; $("cAccent").value = p.accent; $("cTexte").value = p.texte; $("cSombre").value = p.sombre;
  document.querySelectorAll(".palette").forEach((el, j) => { el.className = "palette" + (j === i ? " actif" : ""); });
  majPastilles();
}

function remplirPalettes() {
  const box = $("palettes");
  PALETTES.forEach((p, i) => {
    const d = document.createElement("div");
    d.className = "palette";
    d.title = p.nom;
    [p.fond, p.accent, p.texte, p.sombre].forEach((h) => {
      const s = document.createElement("div");
      s.style.backgroundColor = h;
      d.appendChild(s);
    });
    d.addEventListener("click", () => choisirPalette(i));
    box.appendChild(d);
  });
}

function listePolices() {
  const liste = [];
  try {
    const f = app.fonts;
    for (let i = 0; i < f.length; i++) {
      const x = f[i];
      if (x && x.postScriptName) liste.push({ ps: x.postScriptName, nom: x.name || x.postScriptName });
    }
  } catch (e) {}
  if (!liste.length) {
    ["Impact", "Arial-Black", "Arial-BoldMT", "ArialMT", "Georgia-Bold", "Georgia", "Verdana-Bold", "Verdana"]
      .forEach((ps) => liste.push({ ps, nom: ps }));
  }
  liste.sort((a, b) => a.nom.localeCompare(b.nom));
  return liste;
}

function remplirPolices() {
  const liste = listePolices();
  const existe = (ps) => liste.some((f) => f.ps === ps);
  const choix = (pref, sauve) => (sauve && existe(sauve) ? sauve : pref.find(existe) || (liste[0] && liste[0].ps));
  const defT = choix(POLICES_TITRE_PREF, lsGet("afm_policeTitre"));
  const defX = choix(POLICES_TEXTE_PREF, lsGet("afm_policeTexte"));
  [["policeTitre", defT], ["policeTexte", defX], ["t3Police", defT]].forEach(([id, def]) => {
    const sel = $(id);
    liste.forEach((f) => {
      const o = document.createElement("option");
      o.value = f.ps; o.textContent = f.nom;
      if (f.ps === def) o.selected = true;
      sel.appendChild(o);
    });
  });
}

async function choisirFichier(type) {
  try {
    const f = await fs.getFileForOpening({ types: ["png", "jpg", "jpeg", "psd", "tif", "tiff", "webp"] });
    if (!f) return;
    state[type] = f;
    afficherNom(type);
    if (type === "logo" && $("memoriser").checked) {
      try { lsSet("afm_logo_token", await fs.createPersistentToken(f)); } catch (e) {}
    }
  } catch (e) { statut("Impossible d'ouvrir le fichier : " + e.message, "erreur"); }
}

async function choisirProduits() {
  try {
    let f = await fs.getFileForOpening({ allowMultiple: true, types: ["png", "jpg", "jpeg", "psd", "tif", "tiff", "webp"] });
    if (!f) return;
    if (!Array.isArray(f)) f = [f];
    state.produits = f.slice(0, 4);
    afficherProduits();
  } catch (e) { statut("Impossible d'ouvrir les fichiers : " + e.message, "erreur"); }
}
function afficherProduits() {
  const n = (state.produits || []).length;
  $("nomProduits").textContent = n ? n + " photo(s) : " + state.produits.map((x) => x.name).join(", ") : "Aucune photo de produit";
}
function afficherNom(type) {
  const el = type === "photo" ? $("nomPhoto") : $("nomLogo");
  el.textContent = state[type] ? state[type].name : (type === "photo" ? "Aucune photo" : "Aucun logo");
}

function effacer(type) {
  state[type] = null;
  if (type === "logo") lsDel("afm_logo_token");
  afficherNom(type);
}

function sauverReglages() {
  lsSet("afm_modele", state.modele);
  lsSet("afm_format", $("format").value);
  lsSet("afm_contact", $("contact").value);
  lsSet("afm_palette", String(state.palette));
  lsSet("afm_couleurs", JSON.stringify([$("cFond").value, $("cAccent").value, $("cTexte").value, $("cSombre").value]));
  lsSet("afm_policeTitre", $("policeTitre").value);
  lsSet("afm_policeTexte", $("policeTexte").value);
  lsSet("afm_fondLogo", $("fondLogo").value);
  lsSet("afm_rendu", $("rendu").value); lsSet("afm_stylePolice", $("stylePolice").value); lsSet("afm_formeCadres", $("formeCadres").value); lsSet("afm_titre3D", $("titre3D").value);
  lsSet("afm_autoCadrage", $("autoCadrage").checked ? "1" : "0");
}

async function restaurer() {
  if (lsGet("afm_fondLogo")) $("fondLogo").value = lsGet("afm_fondLogo");
  if (lsGet("afm_rendu")) $("rendu").value = lsGet("afm_rendu");
  if (lsGet("afm_stylePolice")) $("stylePolice").value = lsGet("afm_stylePolice");
  if (lsGet("afm_formeCadres")) $("formeCadres").value = lsGet("afm_formeCadres");
  if (lsGet("afm_titre3D")) $("titre3D").value = lsGet("afm_titre3D");
  $("autoCadrage").checked = lsGet("afm_autoCadrage", "1") !== "0";
  choisirModele(lsGet("afm_modele", "impact"));
  const f = lsGet("afm_format"); if (f && FORMATS[f]) $("format").value = f;
  $("contact").value = lsGet("afm_contact", "");
  choisirPalette(parseInt(lsGet("afm_palette", "0"), 10) || 0);
  try {
    const c = JSON.parse(lsGet("afm_couleurs", "null"));
    if (Array.isArray(c) && c.length === 4) {
      $("cFond").value = c[0]; $("cAccent").value = c[1]; $("cTexte").value = c[2]; $("cSombre").value = c[3];
      majPastilles();
    }
  } catch (e) {}
  try {
    const t = lsGet("afm_logo_token");
    if (t) { const e = await fs.getEntryForPersistentToken(t); if (e) { state.logo = e; afficherNom("logo"); } }
  } catch (e) {}
}

function majLicence() {
  const ok = verifierCle(lsGet("afm_cle", ""));
  $("licence").className = "licence " + (ok ? "ok" : "essai");
  $("licenceTexte").textContent = ok ? "Licence activée ✓ Merci pour votre achat !" : "Version d'essai : filigrane sur les affiches";
  $("btnLicence").style.display = ok ? "none" : "block";
  if (ok) $("zoneCle").style.display = "none";
  return ok;
}

function activer() {
  const k = $("cle").value;
  const m = $("msgCle");
  if (verifierCle(k)) {
    lsSet("afm_cle", k.trim().toUpperCase());
    m.textContent = "";
    majLicence();
    statut("Licence activée ✓", "ok");
  } else {
    m.textContent = "Clé invalide. Vérifiez la saisie (format AFM-XXXX-XXXX-XXXX).";
    m.className = "msg erreur";
  }
}

function acheter() {
  const z = $("zoneAchat");
  z.style.display = z.style.display === "none" ? "block" : "none";
}
async function copier(txt, el) {
  try { await navigator.clipboard.writeText(txt.replace(/\s/g, "")); el.textContent = "Copié ✓"; setTimeout(() => (el.textContent = "Copier"), 1500); }
  catch (e) { el.textContent = txt; }
}
function initAchat() {
  $("achatPrix").textContent = PAIEMENT.prix ? "Prix de la licence : " + PAIEMENT.prix : "";
  $("numOrange").textContent = PAIEMENT.orange;
  $("numMoov").textContent = PAIEMENT.moov;
  $("copOrange").addEventListener("click", () => copier(PAIEMENT.orange, $("copOrange")));
  $("copMoov").addEventListener("click", () => copier(PAIEMENT.moov, $("copMoov")));
  $("btnBoutique").addEventListener("click", async () => {
    try { await uxp.shell.openExternal(PAIEMENT.boutique, "Ouvrir la boutique Mr Doamba"); }
    catch (e) { $("msgCle").textContent = "Boutique : " + PAIEMENT.boutique; }
  });
  $("btnPreuve").addEventListener("click", async () => {
    try { await uxp.shell.openExternal(URL_ACHAT, "Envoyer la preuve de paiement sur WhatsApp"); }
    catch (e) { $("msgCle").textContent = "WhatsApp : +" + PAIEMENT.whatsapp; }
  });
}

/* =====================================================================
 * OUTILS RAPIDES (détourage, arrière-plan, lueurs, retouche)
 * ===================================================================== */
const CIBLE = { _ref: "layer", _enum: "ordinal", _value: "targetEnum" };
const COULEURS_LUEUR = [
  ["Blanc", "#FFFFFF"], ["Jaune", "#FFE600"], ["Or", "#FFB800"], ["Orange", "#FF7A00"], ["Rouge", "#FF1E1E"],
  ["Rose", "#FF2EA6"], ["Violet", "#9B30FF"], ["Bleu", "#1E6BFF"], ["Cyan", "#00E5FF"], ["Vert", "#2EFF6A"]
];

async function bpx(d) {
  const r = await batchPlay(Array.isArray(d) ? d : [d], {});
  for (const x of r) if (x && x._obj === "error") throw new Error(x.message || "commande refusée par Photoshop");
  return r;
}

function statutOutils(msg, type) {
  const s = $("statutOutils");
  s.textContent = msg;
  s.className = "msg" + (type ? " " + type : "");
}

function verifierCalque() {
  if (!app.documents.length) throw new Error("Ouvre d'abord une image dans Photoshop.");
  const ls = app.activeDocument.activeLayers;
  if (!ls.length) throw new Error("Sélectionne un calque dans le panneau Calques.");
  return ls[0];
}

async function outil(nom, fn) {
  try { verifierCalque(); } catch (e) { statutOutils(e.message, "erreur"); return; }
  statutOutils(nom + "…");
  try {
    await core.executeAsModal(async (ctx) => {
      const doc = app.activeDocument;
      let hid = null;
      try { hid = await ctx.hostControl.suspendHistory({ documentID: doc.id, name: nom }); } catch (e) {}
      try { await fn(); }
      finally { if (hid !== null) { try { await ctx.hostControl.resumeHistory(hid); } catch (e) {} } }
    }, { commandName: nom });
    statutOutils(nom + " ✓", "ok");
  } catch (e) {
    console.error(e);
    statutOutils("Erreur : " + (e && e.message ? e.message : e), "erreur");
  }
}

async function selectionnerCalque(id) {
  await bpx({ _obj: "select", _target: [{ _ref: "layer", _id: id }], makeVisible: false });
}
async function deselectionner() {
  await bpx({ _obj: "set", _target: [{ _ref: "channel", _property: "selection" }], to: { _enum: "ordinal", _value: "none" } });
}
async function masqueDepuisSelection() {
  await bpx({ _obj: "make", new: { _class: "channel" },
    at: { _ref: "channel", _enum: "channel", _value: "mask" },
    using: { _enum: "userMaskEnabled", _value: "revealSelection" } });
}
async function selectionnerSujet() {
  await bpx({ _obj: "autoCutout", sampleAllLayers: false });
}
async function debloquerFond(l) {
  if (l.isBackgroundLayer) {
    await bpx({ _obj: "set", _target: [{ _ref: "layer", _property: "background" }],
      to: { _obj: "layer", opacity: pct(100), mode: { _enum: "blendMode", _value: "normal" } } });
  }
}

// ✂ Détourage rapide : sujet seul sur un nouveau calque, original masqué
async function detourageRapide() {
  const l = verifierCalque();
  await selectionnerSujet();
  const copie = await l.duplicate();
  copie.name = l.name + " - détouré";
  await selectionnerCalque(copie.id);
  await masqueDepuisSelection();
  l.visible = false;
  await deselectionner();
}

// 🧹 Supprimer l'arrière-plan : masque sur le calque lui-même
async function supprimerFond() {
  const l = verifierCalque();
  try {
    await bpx({ _obj: "removeBackground" });
  } catch (e) {
    await debloquerFond(l);
    await selectionnerSujet();
    await masqueDepuisSelection();
    await deselectionner();
  }
}

// ✨ Lueurs
function couleurLueur() {
  const v = ($("cLueur").value || "").trim();
  return hexValide(v) ? "#" + v.replace("#", "") : "#FFE600";
}
async function lireEffets() {
  const r = await batchPlay([{ _obj: "get", _target: [{ _property: "layerEffects" }, CIBLE] }], {});
  const fx = r && r[0] && r[0].layerEffects;
  return fx ? JSON.parse(JSON.stringify(fx)) : { _obj: "layerEffects", scale: pct(100) };
}
async function ecrireEffets(fx) {
  await bpx({ _obj: "set", _target: [{ _ref: "property", _property: "layerEffects" }, CIBLE], to: fx });
}
function effetLueur(type, hex, taille, intensite) {
  const e = {
    _obj: type, enabled: true, present: true, showInDialog: true,
    mode: { _enum: "blendMode", _value: "screen" },
    color: rgb(hex), opacity: pct(intensite),
    glowTechnique: { _enum: "matteTechnique", _value: "softMatte" },
    chokeMatte: px(type === "innerGlow" ? 0 : 8), blur: px(taille),
    noise: pct(0), shadingNoise: pct(0), antiAlias: false,
    transferSpec: { _obj: "shapeCurveType", name: "Linéaire" }, inputRange: pct(50)
  };
  if (type === "innerGlow") e.innerGlowSource = { _enum: "innerGlowSourceType", _value: "edgeGlow" };
  return e;
}
async function appliquerLueur(types) {
  const l = verifierCalque();
  await debloquerFond(l);
  const hex = couleurLueur();
  const taille = parseInt($("tailleLueur").value, 10) || 40;
  const intens = parseInt($("intensLueur").value, 10) || 80;
  const nouveaux = {};
  for (const t of types) {
    nouveaux[t] = effetLueur(t, hex, t === "innerGlow" && types.length > 1 ? Math.max(5, Math.round(taille / 4)) : taille, intens);
  }
  try {
    const fx = await lireEffets();
    Object.assign(fx, nouveaux);
    await ecrireEffets(fx);
  } catch (e) {
    await ecrireEffets(Object.assign({ _obj: "layerEffects", scale: pct(100) }, nouveaux));
  }
}
async function retirerLueurs() {
  verifierCalque();
  const fx = await lireEffets();
  let change = false;
  ["outerGlow", "innerGlow"].forEach((k) => { if (fx[k]) { fx[k].enabled = false; change = true; } });
  if (change) await ecrireEffets(fx);
}

// 🎨 Retouches (calques de réglage écrêtés sur le calque choisi)
async function reglage(nom, type) {
  verifierCalque();
  await bpx({ _obj: "make", _target: [{ _ref: "adjustmentLayer" }],
    using: { _obj: "adjustmentLayer", name: nom, group: true, type } });
}
const pointCourbe = (h, v) => ({ _obj: "paint", horizontal: h, vertical: v });
const RETOUCHES = {
  rEclat: ["Éclaircir", () => reglage("Éclaircir", { _obj: "brightnessEvent", brightness: 18, center: 12, useLegacy: false })],
  rContraste: ["Contraste", () => reglage("Contraste", { _obj: "curves",
    presetKind: { _enum: "presetKindType", _value: "presetKindCustom" },
    adjustment: [{ _obj: "curvesAdjustment", channel: { _ref: "channel", _enum: "channel", _value: "composite" },
      curve: [pointCourbe(0, 0), pointCourbe(64, 50), pointCourbe(192, 206), pointCourbe(255, 255)] }] })],
  rVives: ["Couleurs vives", () => reglage("Couleurs vives", { _obj: "vibrance", vibrance: 45, saturation: 10 })],
  rChaud: ["Tons chauds", () => reglage("Tons chauds", { _obj: "photoFilter",
    color: { _obj: "labColor", luminance: 67, a: 32, b: 66 }, density: 30, preserveLuminosity: true })],
  rFroid: ["Tons froids", () => reglage("Tons froids", { _obj: "photoFilter",
    color: { _obj: "labColor", luminance: 64, a: -2, b: -55 }, density: 30, preserveLuminosity: true })],
  rNB: ["Noir et blanc", () => reglage("Noir et blanc", { _obj: "hueSaturation",
    presetKind: { _enum: "presetKindType", _value: "presetKindCustom" }, colorize: false,
    adjustment: [{ _obj: "hueSatAdjustmentV2", hue: 0, saturation: -100, lightness: 0 }] })],
  rNettete: ["Netteté", async () => {
    verifierCalque();
    await bpx({ _obj: "unsharpMask", amount: pct(80), radius: px(1.2), threshold: 2 });
  }],
  rPeau: ["Peau lisse", async () => {
    const l = verifierCalque();
    const copie = await l.duplicate();
    copie.name = "Peau lisse";
    await selectionnerCalque(copie.id);
    await bpx({ _obj: "surfaceBlur", radius: px(8), threshold: 15 });
    copie.opacity = 55;
  }]
};

function initOutils() {
  const box = $("couleursLueur");
  COULEURS_LUEUR.forEach(([nom, hex], i) => {
    const d = document.createElement("div");
    d.className = "pastilleL" + (i === 1 ? " actif" : "");
    d.title = nom;
    d.style.backgroundColor = hex;
    d.addEventListener("click", () => {
      $("cLueur").value = hex;
      document.querySelectorAll(".pastilleL").forEach((x) => (x.className = "pastilleL"));
      d.className = "pastilleL actif";
      majLueur();
    });
    box.appendChild(d);
  });
  const majLueur = () => { $("vLueur").style.backgroundColor = couleurLueur(); };
  $("cLueur").addEventListener("input", majLueur);
  majLueur();
  $("tailleLueur").addEventListener("input", () => ($("vTaille").textContent = $("tailleLueur").value));
  $("intensLueur").addEventListener("input", () => ($("vIntens").textContent = $("intensLueur").value));

  $("oDetour").addEventListener("click", () => outil("Détourage rapide", detourageRapide));
  $("oSupprFond").addEventListener("click", () => outil("Supprimer l'arrière-plan", supprimerFond));
  $("oLueurExt").addEventListener("click", () => outil("Lueur externe", () => appliquerLueur(["outerGlow"])));
  $("oLueurInt").addEventListener("click", () => outil("Lueur interne", () => appliquerLueur(["innerGlow"])));
  $("oNeon").addEventListener("click", () => outil("Effet néon", () => appliquerLueur(["outerGlow", "innerGlow"])));
  $("oSansLueur").addEventListener("click", () => outil("Retirer les lueurs", retirerLueurs));
  Object.keys(RETOUCHES).forEach((id) => {
    const [nom, fn] = RETOUCHES[id];
    $(id).addEventListener("click", () => outil(nom, fn));
  });

}

/* =====================================================================
 * TEXTE 3D
 * ===================================================================== */
const COMBOS_3D = [
  ["Jaune / Orange", "#FFD43B", "#C2410C"], ["Blanc / Bleu", "#FFFFFF", "#1E3A8A"], ["Rouge / Bordeaux", "#EF4444", "#7F1D1D"],
  ["Vert / Forêt", "#4ADE80", "#14532D"], ["Rose / Violet", "#FF4D9D", "#5B21B6"], ["Cyan / Nuit", "#22D3EE", "#0C1E3E"],
  ["Orange / Brun", "#FB923C", "#7C2D12"], ["Blanc / Noir", "#FFFFFF", "#111111"],
  ["Blanc / Rose", "#FFFFFF", "#D6006F"], ["Blanc / Bleu roi", "#FFFFFF", "#0A2FD6"], ["Cyan / Marine", "#29B6F6", "#1A1F4D"], ["Pierre / Vert", "#CDD1D6", "#22A35A"]
];
const ang = (v) => ({ _unit: "angleUnit", _value: v });
const lineaire = { _obj: "shapeCurveType", name: "Linéaire" };
function fxRemplissage(hex) {
  return { _obj: "solidFill", enabled: true, present: true, showInDialog: true, mode: { _enum: "blendMode", _value: "normal" }, opacity: pct(100), color: rgb(hex) };
}
function fxDegrade(nom, stops, angle) {
  return { _obj: "gradientFill", enabled: true, present: true, showInDialog: true, mode: { _enum: "blendMode", _value: "normal" }, opacity: pct(100),
    gradient: { _obj: "gradientClassEvent", name: nom, gradientForm: { _enum: "gradientForm", _value: "customStops" }, interfaceIconFrameDimmed: 4096,
      colors: stops.map(([hex, loc]) => ({ _obj: "colorStop", color: rgb(hex), type: { _enum: "colorStopType", _value: "userStop" }, location: Math.round(loc * 4096), midpoint: 50 })),
      transparency: [{ _obj: "transferSpec", opacity: pct(100), location: 0, midpoint: 50 }, { _obj: "transferSpec", opacity: pct(100), location: 4096, midpoint: 50 }] },
    angle: ang(angle || 90), type: { _enum: "gradientType", _value: "linear" }, reverse: false, dither: false, align: true, scale: pct(100),
    offset: { _obj: "paint", horizontal: pct(0), vertical: pct(0) } };
}
function fxBiseau(taille, force) {
  return { _obj: "bevelEmboss", enabled: true, present: true, showInDialog: true,
    highlightMode: { _enum: "blendMode", _value: "screen" }, highlightColor: rgb("#FFFFFF"), highlightOpacity: pct(80),
    shadowMode: { _enum: "blendMode", _value: "multiply" }, shadowColor: rgb("#000000"), shadowOpacity: pct(55),
    bevelTechnique: { _enum: "bevelTechnique", _value: "softMatte" }, bevelStyle: { _enum: "bevelEmbossStyle", _value: "innerBevel" },
    useGlobalAngle: false, localLightingAngle: ang(120), localLightingAltitude: ang(30), strengthRatio: pct(force || 100),
    blur: px(Math.max(1, Math.round(taille))), bevelDirection: { _enum: "bevelEmbossStampStyle", _value: "stampIn" },
    transferSpec: lineaire, antialiasGloss: false, softness: px(0), useShape: false, useTexture: false };
}
function fxOmbre(hex, distance, flou, opacite, angle) {
  return { _obj: "dropShadow", enabled: true, present: true, showInDialog: true, mode: { _enum: "blendMode", _value: "multiply" },
    color: rgb(hex), opacity: pct(opacite), useGlobalAngle: false, localLightingAngle: ang(angle),
    distance: px(Math.round(distance)), chokeMatte: px(0), blur: px(Math.round(flou)), noise: pct(0), antiAlias: false,
    transferSpec: lineaire, layerConceals: true };
}
function fxContour(hex, taille) {
  return { _obj: "frameFX", enabled: true, present: true, showInDialog: true, style: { _enum: "frameStyle", _value: "outsetFrame" },
    paintType: { _enum: "frameFill", _value: "solidColor" }, mode: { _enum: "blendMode", _value: "normal" }, opacity: pct(100),
    size: px(Math.max(1, Math.round(taille))), color: rgb(hex), overprint: false };
}
const OR = [["#7A5200", 0], ["#FFE58A", 0.32], ["#C9961A", 0.52], ["#FFF3B0", 0.74], ["#8C6200", 1]];
const CHROME = [["#2B2F33", 0], ["#F5F7FA", 0.44], ["#8A939C", 0.5], ["#E6EBF0", 0.8], ["#4A5058", 1]];

function hexOu(v, def) { v = String(v || "").trim(); return hexValide(v) ? "#" + v.replace("#", "") : def; }
async function ajouterSelection(id) {
  await bpx({ _obj: "select", _target: [{ _ref: "layer", _id: id }], selectionModifier: { _enum: "selectionModifierType", _value: "addToSelection" }, makeVisible: false });
}
async function grouper(ids, nom) {
  await selectionnerCalque(ids[0]);
  for (const id of ids.slice(1)) await ajouterSelection(id);
  await bpx({ _obj: "make", _target: [{ _ref: "layerSection" }], from: { _ref: "layer", _enum: "ordinal", _value: "targetEnum" } });
  actif().name = nom;
}

/* ---------- Styles 3D (modernes 2026 + classiques) ---------- */
function nuance(hex, f) {               // f > 0 : vers le blanc, f < 0 : vers le noir
  const c = hexToRgb(hex), t = f < 0 ? 0 : 255, k = Math.min(1, Math.abs(f));
  const m = (v) => Math.round(v + (t - v) * k).toString(16).padStart(2, "0");
  return ("#" + m(c.r) + m(c.g) + m(c.b)).toUpperCase();
}
function fxOmbreInt(hex, distance, flou, opacite, angle, mode) {
  return { _obj: "innerShadow", enabled: true, present: true, showInDialog: true, mode: { _enum: "blendMode", _value: mode || "multiply" },
    color: rgb(hex), opacity: pct(opacite), useGlobalAngle: false, localLightingAngle: ang(angle),
    distance: px(Math.round(distance)), chokeMatte: px(0), blur: px(Math.max(1, Math.round(flou))), noise: pct(0), antiAlias: false, transferSpec: lineaire };
}
function fxGrain(hex, taille, opacite, bruit) {
  const e = effetLueur("innerGlow", hex, Math.round(taille), opacite);
  e.mode = { _enum: "blendMode", _value: "multiply" };
  e.noise = pct(bruit);
  e.innerGlowSource = { _enum: "innerGlowSourceType", _value: "centerGlow" };
  return e;
}
function fxContourDegrade(nom, stops, taille) {
  const g = fxDegrade(nom, stops, 90);
  return { _obj: "frameFX", enabled: true, present: true, showInDialog: true, style: { _enum: "frameStyle", _value: "outsetFrame" },
    paintType: { _enum: "frameFill", _value: "gradientFill" }, mode: { _enum: "blendMode", _value: "normal" }, opacity: pct(100),
    size: px(Math.max(1, Math.round(taille))), gradient: g.gradient, angle: g.angle, type: g.type, reverse: false, dither: false,
    align: true, scale: pct(100), offset: g.offset, overprint: false };
}
function fxBrillance(taille, force, ombre) {     // biseau « laqué » très lumineux
  const e = fxBiseau(taille, force);
  e.highlightOpacity = pct(100);
  e.shadowOpacity = pct(ombre == null ? 45 : ombre);
  e.localLightingAltitude = ang(55);
  e.bevelTechnique = { _enum: "bevelTechnique", _value: "softMatte" };
  return e;
}
const fx = (o) => Object.assign({ _obj: "layerEffects", scale: pct(100) }, o);
const OR_VIF = [["#8A5A00", 0], ["#FFD86B", 0.28], ["#B8860B", 0.5], ["#FFF1A8", 0.72], ["#A06A00", 1]];

const STYLES_3D = {
  // ---- Modernes 2026 ----
  cartoon: { nom: "Cartoon brillant", def: ["#FFFFFF", "#D6006F"], prof: true,
    tranche: (c) => fx({ solidFill: fxRemplissage(c.T) }),
    apres: (c) => fx({ frameFX: fxContour(nuance(c.T, 0.3), c.h * 0.035), dropShadow: fxOmbre(nuance(c.T, -0.6), c.h * 0.12, c.h * 0.25, 55, c.L) }),
    face: (c) => fx({ gradientFill: fxDegrade("Laqué", [[nuance(c.F, -0.18), 0], [c.F, 0.55], [c.F, 1]], 90),
      bevelEmboss: fxBrillance(c.h * 0.05, 130), frameFX: fxContour(nuance(c.T, 0.15), c.h * 0.012) }),
    extras: async (c) => [await etincelle(c, c.b.x + c.b.w * 0.97, c.b.y + c.h * 0.02, "#FFFFFF")] },
  luxe: { nom: "Luxe blanc & or", def: ["#FFFFFF", "#C9961A"], prof: true, fixes: true,
    tranche: () => fx({ gradientFill: fxDegrade("Or", OR_VIF, 0) }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.h * 0.08, c.h * 0.2, 35, c.L), bevelEmboss: fxBiseau(c.h * 0.015, 80) }),
    face: (c) => fx({ gradientFill: fxDegrade("Émail", [["#D5D9DF", 0], ["#FFFFFF", 0.6], ["#F3F4F6", 1]], 90),
      bevelEmboss: fxBrillance(c.h * 0.05, 90, 25), innerShadow: fxOmbreInt("#000000", c.h * 0.01, c.h * 0.04, 22, c.L),
      frameFX: fxContourDegrade("Liseré or", OR_VIF, c.h * 0.03) }) },
  verre: { nom: "Verre liquide", def: ["#FFFFFF", "#FF8A00"], prof: false, remplissage: 8,
    face: (c) => fx({ bevelEmboss: Object.assign(fxBrillance(c.h * 0.09, 220, 60), { shadowColor: rgb(nuance(c.T, -0.35)) }),
      innerGlow: Object.assign(effetLueur("innerGlow", c.T, Math.round(c.h * 0.11), 100), { mode: { _enum: "blendMode", _value: "normal" } }),
      innerShadow: fxOmbreInt(nuance(c.T, -0.2), c.h * 0.025, c.h * 0.06, 75, c.L),
      frameFX: fxContour(nuance(c.T, -0.25), c.h * 0.006),
      dropShadow: fxOmbre(nuance(c.T, -0.3), c.h * 0.06, c.h * 0.14, 35, c.L) }),
    extras: async (c) => bulles(c) },
  gaming: { nom: "Gaming (pierre + contour)", def: ["#CDD1D6", "#22A35A"], prof: true,
    tranche: (c) => fx({ solidFill: fxRemplissage(nuance(c.T, -0.45)) }),
    apres: (c) => fx({ frameFX: fxContour(c.T, c.h * 0.07), outerGlow: effetLueur("outerGlow", c.T, Math.round(c.h * 0.14), 65),
      dropShadow: fxOmbre("#000000", c.h * 0.08, c.h * 0.2, 50, c.L) }),
    face: (c) => fx({ innerGlow: fxGrain("#2F3438", c.h * 0.6, 60, 85), bevelEmboss: fxBiseau(c.h * 0.035, 110),
      innerShadow: fxOmbreInt("#000000", c.h * 0.012, c.h * 0.03, 35, c.L) }) },
  graffiti: { nom: "Graffiti urbain", def: ["#29B6F6", "#1A1F4D"], prof: true,
    tranche: (c) => fx({ solidFill: fxRemplissage(c.T), frameFX: fxContour(nuance(c.T, -0.55), Math.max(1, c.h * 0.006)) }),
    apres: (c) => fx({ frameFX: fxContour(nuance(c.T, -0.6), c.h * 0.02), dropShadow: fxOmbre("#000000", c.h * 0.1, c.h * 0.22, 55, c.L) }),
    face: (c) => fx({ gradientFill: fxDegrade("Graffiti", [[nuance(c.F, -0.35), 0], [c.F, 0.55], [nuance(c.F, 0.5), 1]], 90),
      bevelEmboss: fxBrillance(c.h * 0.06, 170), frameFX: fxContour(nuance(c.T, -0.3), c.h * 0.03) }) },
  eclat: { nom: "Grand éclat (néon + or)", def: ["#FFD54A", "#C2410C"], prof: true,
    tranche: (c) => fx({ gradientFill: fxDegrade("Profondeur", [[nuance(c.T, -0.45), 0], [c.T, 1]], 90) }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.h * 0.1, c.h * 0.25, 55, c.L) }),
    face: (c) => fx({ gradientFill: fxDegrade("Éclat", [[nuance(c.F, -0.3), 0], [c.F, 0.5], ["#FFFBEA", 1]], 90),
      bevelEmboss: fxBrillance(c.h * 0.05, 150), frameFX: fxContour(nuance(c.F, 0.35), c.h * 0.01) }),
    extras: async (c) => [await contourNeon(c, "#2EC5FF"), ...(await reflet(c))] },
  // ---- Classiques ----
  extrude: { nom: "Extrudé", def: ["#FFD43B", "#C2410C"], prof: true,
    tranche: (c) => fx({ solidFill: fxRemplissage(c.T) }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.prof * 0.5, c.prof * 0.9, 50, c.L) }),
    face: (c) => fx({ bevelEmboss: fxBiseau(c.h * 0.02, 70) }) },
  relief: { nom: "Relief", def: ["#FFFFFF", "#1E3A8A"], prof: false,
    face: (c) => fx({ bevelEmboss: fxBiseau(c.h * 0.06, 150), dropShadow: fxOmbre(c.T, c.h * 0.08, c.h * 0.1, 75, c.L) }) },
  or: { nom: "Doré", def: ["#FFD43B", "#5C3D00"], prof: true, fixes: true,
    tranche: () => fx({ solidFill: fxRemplissage("#5C3D00") }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.prof * 0.5, c.prof * 0.9, 50, c.L) }),
    face: (c) => fx({ gradientFill: fxDegrade("Or", OR, 90), bevelEmboss: fxBiseau(c.h * 0.03, 120) }) },
  chrome: { nom: "Chromé", def: ["#E6EBF0", "#30363C"], prof: true, fixes: true,
    tranche: () => fx({ solidFill: fxRemplissage("#30363C") }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.prof * 0.5, c.prof * 0.9, 50, c.L) }),
    face: (c) => fx({ gradientFill: fxDegrade("Chrome", CHROME, 90), bevelEmboss: fxBiseau(c.h * 0.03, 120) }) },
  neon: { nom: "Néon 3D", def: ["#22D3EE", "#0C1E3E"], prof: true,
    tranche: (c) => fx({ solidFill: fxRemplissage(c.T) }),
    apres: (c) => fx({ dropShadow: fxOmbre("#000000", c.prof * 0.5, c.prof * 0.9, 50, c.L) }),
    face: (c) => fx({ outerGlow: effetLueur("outerGlow", c.F, Math.round(c.h * 0.25), 90), innerGlow: effetLueur("innerGlow", "#FFFFFF", Math.round(c.h * 0.04), 60) }) },
  sticker: { nom: "Sticker", def: ["#FF4D9D", "#5B21B6"], prof: false,
    face: (c) => fx({ frameFX: fxContour("#FFFFFF", c.h * 0.06),
      dropShadow: Object.assign(fxOmbre(c.T, c.h * 0.1, 0, 100, c.L), { mode: { _enum: "blendMode", _value: "normal" } }) }) }
};

async function remplissageCalque(id, opacite) {
  await bpx({ _obj: "set", _target: [{ _ref: "layer", _id: id }], to: { _obj: "layer", fillOpacity: pct(opacite) } });
}
async function etincelle(c, x, y, hex) {
  const h = c.h, ids = [];
  const a = await forme("Étincelle", "ellipse", x - h * 0.4, y - h * 0.025, h * 0.8, h * 0.05, "#FFFFFF"); ids.push(a.id);
  const v = await forme("Étincelle", "ellipse", x - h * 0.025, y - h * 0.3, h * 0.05, h * 0.6, "#FFFFFF"); ids.push(v.id);
  const p = await forme("Étincelle", "ellipse", x - h * 0.07, y - h * 0.07, h * 0.14, h * 0.14, "#FFFFFF"); ids.push(p.id);
  for (const id of ids) { await selectionnerCalque(id); await ecrireEffets(fx({ outerGlow: effetLueur("outerGlow", hex, Math.round(h * 0.15), 90) })); }
  await grouper(ids, "Étincelle");
  return actif().id;
}
async function bulles(c) {
  const { b, h } = c, ids = [];
  const pos = [[b.x - h * 0.25, b.y + h * 0.05, 0.13], [b.x + b.w * 0.55, b.y - h * 0.45, 0.17], [b.x + b.w * 0.74, b.y - h * 0.22, 0.06],
               [b.x + b.w * 0.1, b.y + b.h + h * 0.12, 0.1], [b.x + b.w + h * 0.12, b.y + b.h * 0.25, 0.08]];
  for (const [x, y, r] of pos) {
    const R = h * r;
    const l = await forme("Bulle", "ellipse", x - R, y - R, 2 * R, 2 * R, "#FFFFFF");
    await remplissageCalque(l.id, 4);
    await ecrireEffets(fx({ bevelEmboss: fxBrillance(R * 0.6, 200, 50), innerShadow: fxOmbreInt("#5A6270", R * 0.1, R * 0.4, 45, c.L),
      dropShadow: fxOmbre("#000000", R * 0.3, R * 0.5, 25, c.L) }));
    ids.push(l.id);
  }
  await grouper(ids, "Bulles");
  return [actif().id];
}
async function contourNeon(c, hex) {
  const n = await c.faceL.duplicate();
  n.name = "Contour néon";
  await selectionnerCalque(n.id);
  await ecrireEffets(fx({ frameFX: fxContour(hex, c.h * 0.012), outerGlow: effetLueur("outerGlow", hex, Math.round(c.h * 0.1), 85) }));
  await remplissageCalque(n.id, 0);
  await n.scale(116, 116);
  await centrer(n, c.b.x + c.b.w / 2, c.b.y + c.b.h / 2 - c.h * 0.06);
  try { await n.move(c.bas, constants.ElementPlacement.PLACEAFTER); } catch (e) {}
  return n.id;
}
async function reflet(c) {
  const { b, h } = c, cx = b.x + b.w / 2, cy = b.y + b.h * 0.82, ids = [];
  const s = await forme("Reflet", "ellipse", cx - b.w * 0.22, cy - h * 0.015, b.w * 0.44, h * 0.03, "#FFFFFF"); ids.push(s.id);
  const p = await forme("Reflet", "ellipse", cx - h * 0.06, cy - h * 0.06, h * 0.12, h * 0.12, "#FFFFFF"); ids.push(p.id);
  for (const id of ids) { await selectionnerCalque(id); await ecrireEffets(fx({ outerGlow: effetLueur("outerGlow", "#FFB020", Math.round(h * 0.22), 90) })); }
  return ids;
}

// Transforme un calque de texte déjà placé en texte 3D (utilisé par l'onglet Texte 3D et par les titres d'affiche)
async function rendre3D(l, cle, F, T, profPct, dir, nomTexte, lignes) {
  const st = STYLES_3D[cle] || STYLES_3D.cartoon;
  if (st.fixes) { F = st.def[0]; T = st.def[1]; }
  const doc = app.activeDocument;
  const W = doc.width, H = doc.height, s = Math.min(W, H);
  const b = bornes(l), h = b.h / Math.max(1, lignes || 1);       // hauteur d'une ligne
  const c = { F, T, h, b, s, W, H, L: 180 - dir, prof: 0, faceL: l, bas: l };
  const ids = [];
  if (st.prof) {
    const prof = Math.max(4, h * profPct / 100);
    c.prof = prof;
    const N = Math.max(8, Math.min(60, Math.round(prof / Math.max(1, s / 600))));
    const pas = prof / N, rad = dir * Math.PI / 180, dx = Math.cos(rad) * pas, dy = Math.sin(rad) * pas;
    await selectionnerCalque(l.id);
    await ecrireEffets(st.tranche(c));
    await l.translate(dx * N, dy * N);
    const pile3d = [l.id];
    let cur = l;
    for (let i = 0; i < N; i++) { cur = await cur.duplicate(); await cur.translate(-dx, -dy); pile3d.push(cur.id); }
    c.faceL = cur; pile3d.pop();
    await selectionnerCalque(pile3d[0]);
    for (const id of pile3d.slice(1)) await ajouterSelection(id);
    await bpx({ _obj: "mergeLayersNew" });
    const p = actif(); p.name = "Profondeur 3D";
    if (st.apres) await ecrireEffets(st.apres(c));
    c.bas = p;
    ids.push(p.id);
  }
  c.faceL.name = "Face (texte modifiable)";
  await selectionnerCalque(c.faceL.id);
  await ecrireEffets(st.face(c));
  if (st.remplissage != null) await remplissageCalque(c.faceL.id, st.remplissage);
  ids.push(c.faceL.id);
  if (st.extras) { try { ids.push(...(await st.extras(c))); } catch (e) { console.error(e); } }
  await grouper(ids, "Texte 3D - " + st.nom + " - " + String(nomTexte || "").replace(/\s+/g, " ").substr(0, 16));
  return actif();
}

async function creerTexte3D() {
  let txt = ($("t3Texte").value || "").trim() || "TEXTE 3D";
  if ($("t3Maj").checked) txt = txt.toUpperCase();
  const cle = STYLES_3D[$("t3Style").value] ? $("t3Style").value : "cartoon";
  const st = STYLES_3D[cle];
  const F = hexOu($("t3Face").value, st.def[0]), T = hexOu($("t3Tranche").value, st.def[1]);
  const profPct = parseInt($("t3Prof").value, 10) || 14;
  const dir = parseFloat($("t3Dir").value) || 0;
  const police = $("t3Police").value || "Arial-BoldMT";
  if (!app.documents.length) {
    await app.documents.add({ width: 1080, height: 1080, resolution: 72, mode: constants.NewDocumentMode.RGB, fill: constants.DocumentFill.WHITE, name: "Texte 3D" });
    await fond(st === STYLES_3D.luxe || st === STYLES_3D.verre ? "#C9CED6" : nuance(T, -0.2));
  }
  const doc = app.activeDocument;
  const W = doc.width, H = doc.height;
  const coupe = couper(txt, 14);
  const l = await texte("Texte 3D", coupe, { police, taille: 60, interligne: 58, couleur: st.fixes ? st.def[0] : F });
  const b0 = bornes(l);
  const r = Math.min((W * 0.78) / b0.w, (H * 0.5) / b0.h);
  await l.scale(r * 100, r * 100);
  await centrer(l, W / 2, H / 2);
  await rendre3D(l, cle, F, T, profPct, dir, txt, coupe.split("\n").length);
}

// Titre de l'affiche en 3D (après la mise en page)
async function titreEn3D(c) {
  const cle = state.titre3D;
  if (!cle || cle === "aucun" || !STYLES_3D[cle]) return;
  const t = Array.from(app.activeDocument.layers).find((x) => x.name === "Titre");
  if (!t) return;
  // le titre garde sa couleur ; la profondeur prend l'accent (ou une teinte sombre si l'accent est trop proche)
  const face = c.P.texte, prof = Math.abs(hexToRgb(c.P.accent).r - hexToRgb(face).r) < 40 ? nuance(c.P.fond, -0.45) : c.P.accent;
  const lignes = String(c.T.titre || "").length > 0 ? couper(c.T.titre, 14).split("\n").length : 1;
  await rendre3D(t, cle, face, cle === "cartoon" || cle === "graffiti" ? nuance(c.P.fond, -0.35) : prof, 12, 45, c.T.titre, Math.min(3, lignes));
}

const TITRES_PRETS = [
  ["GRANDE PROMO", "cartoon", "#FFFFFF", "#D6006F"], ["SOLDES", "eclat", "#FFD54A", "#C2410C"], ["BLACK FRIDAY", "luxe", "#FFFFFF", "#C9961A"],
  ["NOUVEAU", "cartoon", "#FFFFFF", "#0A2FD6"], ["-50%", "graffiti", "#FFD43B", "#7F1D1D"], ["GRATUIT", "cartoon", "#FFFFFF", "#16A34A"],
  ["JOYEUX ANNIVERSAIRE", "cartoon", "#FFFFFF", "#9B30FF"], ["BONNE FÊTE", "luxe", "#FFFFFF", "#C9961A"], ["GRANDE SOIRÉE", "eclat", "#FFD54A", "#C2410C"],
  ["BIENVENUE", "verre", "#FFFFFF", "#FF8A00"], ["OUVERTURE", "eclat", "#FFD54A", "#C2410C"], ["À VENDRE", "graffiti", "#29B6F6", "#1A1F4D"],
  ["ON RECRUTE", "gaming", "#CDD1D6", "#22A35A"], ["MERCI", "luxe", "#FFFFFF", "#C9961A"], ["LIVE", "neon", "#22D3EE", "#0C1E3E"], ["GAGNANT", "or", "#FFD43B", "#5C3D00"]
];
function initTitresPrets() {
  const box = $("t3Prets");
  TITRES_PRETS.forEach(([txt, st, f, t]) => {
    const d = document.createElement("div");
    d.className = "pret";
    d.textContent = txt;
    d.addEventListener("click", () => {
      $("t3Texte").value = txt; $("t3Style").value = st;
      try { $("t3Style").dispatchEvent(new Event("change")); } catch (e) {}
      $("t3Face").value = f; $("t3Tranche").value = t;
      try { $("t3Face").dispatchEvent(new Event("input")); } catch (e) {}
      document.querySelectorAll(".pret").forEach((x) => (x.className = "pret"));
      d.className = "pret actif";
    });
    box.appendChild(d);
  });
}

function initTexte3D() {
  const box = $("t3Combos");
  const maj = () => { $("v3Face").style.backgroundColor = hexOu($("t3Face").value, "#FFD43B"); $("v3Tranche").style.backgroundColor = hexOu($("t3Tranche").value, "#C2410C"); };
  COMBOS_3D.forEach(([nom, f, t]) => {
    const d = document.createElement("div");
    d.className = "palette"; d.title = nom;
    [f, t].forEach((h) => { const s = document.createElement("div"); s.style.backgroundColor = h; d.appendChild(s); });
    d.addEventListener("click", () => {
      $("t3Face").value = f; $("t3Tranche").value = t; maj();
      document.querySelectorAll("#t3Combos .palette").forEach((x) => (x.className = "palette"));
      d.className = "palette actif";
    });
    box.appendChild(d);
  });
  ["t3Face", "t3Tranche"].forEach((id) => $(id).addEventListener("input", maj));
  const appliquerDefauts = () => {
    const st = STYLES_3D[$("t3Style").value]; if (!st) return;
    $("t3Face").value = st.def[0]; $("t3Tranche").value = st.def[1]; maj();
    $("t3Note").textContent = st.fixes ? "Ce style utilise ses propres couleurs (or, chrome…)." :
      st === STYLES_3D.verre ? "Couleur « Profondeur » = couleur du liquide. Plus beau sur un fond clair." : "";
  };
  $("t3Style").addEventListener("change", appliquerDefauts);
  appliquerDefauts();
  $("t3Prof").addEventListener("input", () => ($("v3Prof").textContent = $("t3Prof").value));
  $("t3Creer").addEventListener("click", async () => {
    const st = $("t3Statut"), btn = $("t3Creer");
    st.textContent = "Création du texte 3D…"; st.className = "msg"; btn.disabled = true;
    try {
      await core.executeAsModal(async (ctx) => {
        let hid = null;
        try { if (app.documents.length) hid = await ctx.hostControl.suspendHistory({ documentID: app.activeDocument.id, name: "Texte 3D" }); } catch (e) {}
        try { await creerTexte3D(); }
        finally { if (hid !== null) { try { await ctx.hostControl.resumeHistory(hid); } catch (e) {} } }
      }, { commandName: "Affiche Minute - Texte 3D" });
      st.textContent = "Texte 3D créé ✓ (groupe « Texte 3D » dans le panneau Calques)"; st.className = "msg ok";
    } catch (e) {
      console.error(e);
      st.textContent = "Erreur : " + (e && e.message ? e.message : e); st.className = "msg erreur";
    } finally { btn.disabled = false; }
  });
  maj();
}

/* =====================================================================
 * MES MODÈLES (PSD personnels)
 * ===================================================================== */
const mState = { dossier: null, fichiers: [], choix: -1 };
const CLES_TEXTE = [
  ["sousTitre", ["sous-titre", "sous titre", "soustitre", "subtitle", "sub title", "subheading", "slogan", "tagline"]],
  ["dateLieu", ["date", "lieu", "location", "venue", "place", "heure", "time", "when"]],
  ["badge", ["badge", "prix", "price", "promo", "offre", "offer", "discount", "remise", "tarif"]],
  ["contact", ["contact", "tel", "phone", "whatsapp", "email", "mail", "site", "web", "www", "adresse", "address", "call"]],
  ["details", ["detail", "description", "desc", "paragraph", "paragraphe", "body", "info", "texte", "text", "lorem"]],
  ["titre", ["titre", "title", "headline", "heading", "header", "nom", "name", "main"]]
];
const sansAccent = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
function cleDuCalque(nom) {
  const n = sansAccent(nom);
  for (const [cle, mots] of CLES_TEXTE) if (mots.some((m) => n.includes(m))) return cle;
  return null;
}
function mStatut(msg, type) { const s = $("mStatut"); s.textContent = msg; s.className = "msg" + (type ? " " + type : ""); }

async function listerPSD(dossier, prefixe, profondeur) {
  let out = [];
  const entrees = await dossier.getEntries();
  for (const e of entrees) {
    if (e.isFile && /\.(psd|psb)$/i.test(e.name)) out.push({ entry: e, nom: prefixe + e.name });
    else if (e.isFolder && profondeur > 0 && !e.name.startsWith(".")) {
      try { out = out.concat(await listerPSD(e, prefixe + e.name + " / ", profondeur - 1)); } catch (err) {}
    }
  }
  return out;
}
function afficherListe() {
  const box = $("mListe");
  box.innerHTML = "";
  if (!mState.dossier) { box.innerHTML = '<div class="vide">Choisis un dossier qui contient tes modèles PSD.</div>'; return; }
  if (!mState.fichiers.length) { box.innerHTML = '<div class="vide">Aucun fichier PSD trouvé dans ce dossier (ni dans ses sous-dossiers).</div>'; return; }
  mState.fichiers.forEach((f, i) => {
    const d = document.createElement("div");
    d.className = "item" + (i === mState.choix ? " actif" : "");
    d.textContent = f.nom;
    d.addEventListener("click", () => { mState.choix = i; afficherListe(); });
    box.appendChild(d);
  });
}
async function chargerDossier(dossier) {
  mState.dossier = dossier; mState.choix = -1;
  $("mNomDossier").textContent = dossier ? dossier.name : "Aucun dossier";
  mState.fichiers = dossier ? (await listerPSD(dossier, "", 2)).sort((a, b) => a.nom.localeCompare(b.nom)) : [];
  afficherListe();
  if (dossier) mStatut(mState.fichiers.length + " modèle(s) trouvé(s).", "ok");
}
function calquesTexte(liste, out) {
  for (const l of liste) {
    if (l.kind === constants.LayerKind.GROUP || l.kind === "group") { if (l.layers) calquesTexte(l.layers, out); }
    else if (l.kind === constants.LayerKind.TEXT || l.kind === "text") out.push(l);
  }
  return out;
}
async function remplacerTexte(l, txt) {
  const t = String(txt).replace(/\r\n|\n/g, "\r");
  try { if (l.textItem) { l.textItem.contents = t; return; } } catch (e) {}
  await bpx({ _obj: "set", _target: [{ _ref: "layer", _id: l.id }], to: { _obj: "textLayer", textKey: t } });
}
async function ouvrirModele(remplir) {
  const f = mState.fichiers[mState.choix];
  if (!f) { mStatut("Clique d'abord sur un modèle dans la liste.", "erreur"); return; }
  const v = lireFormulaire();
  mStatut("Ouverture de « " + f.entry.name + " »…");
  try {
    let rapport = "";
    await core.executeAsModal(async () => {
      const orig = await app.open(f.entry);
      const base = f.entry.name.replace(/\.(psd|psb)$/i, "");
      await bpx({ _obj: "duplicate", _target: [{ _ref: "document", _enum: "ordinal", _value: "targetEnum" }], name: base + " - copie" });
      const copie = app.activeDocument;
      try { await orig.closeWithoutSaving(); } catch (e) {}
      app.activeDocument = copie;
      if (!remplir) return;
      const valeurs = { titre: v.T.titre, sousTitre: v.T.sousTitre, details: v.T.details, dateLieu: v.T.dateLieu, badge: v.T.badge, contact: v.T.contact };
      if (!($("titre").value || "").trim()) valeurs.titre = "";
      const textes = calquesTexte(copie.layers, []);
      const faits = {};
      let n = 0;
      for (const l of textes) {
        if (l.locked) continue;
        const cle = cleDuCalque(l.name);
        if (cle && valeurs[cle] && !faits[cle]) { await remplacerTexte(l, valeurs[cle]); faits[cle] = true; n++; }
      }
      // Pas de calque « titre » : on prend le plus grand texte
      if (!faits.titre && valeurs.titre && textes.length) {
        const libres = textes.filter((l) => !l.locked && !cleDuCalque(l.name));
        const grand = libres.sort((a, b) => bornes(b).h * bornes(b).w - bornes(a).h * bornes(a).w)[0];
        if (grand) { await remplacerTexte(grand, valeurs.titre); faits.titre = true; n++; }
      }
      rapport = n ? n + " texte(s) remplacé(s) : " + Object.keys(faits).join(", ") + "." :
        "Aucun calque de texte reconnu. Renomme les calques de texte (titre, date, contact…) ou modifie-les à la main.";
    }, { commandName: "Affiche Minute - ouvrir un modèle" });
    mStatut(remplir ? "Copie ouverte ✓ " + rapport : "Copie ouverte ✓ (l'original n'est pas modifié)", "ok");
  } catch (e) {
    console.error(e);
    mStatut("Erreur : " + (e && e.message ? e.message : e), "erreur");
  }
}
function initModeles() {
  $("mDossier").addEventListener("click", async () => {
    try {
      const d = await fs.getFolder();
      if (!d) return;
      try { lsSet("afm_dossier_modeles", await fs.createPersistentToken(d)); } catch (e) {}
      await chargerDossier(d);
    } catch (e) { mStatut("Impossible d'ouvrir le dossier : " + e.message, "erreur"); }
  });
  $("mActualiser").addEventListener("click", () => { if (mState.dossier) chargerDossier(mState.dossier); });
  $("mOuvrir").addEventListener("click", () => ouvrirModele(false));
  $("mRemplir").addEventListener("click", () => ouvrirModele(true));
  afficherListe();
  (async () => {
    try { const t = lsGet("afm_dossier_modeles"); if (t) { const d = await fs.getEntryForPersistentToken(t); if (d) await chargerDossier(d); } } catch (e) {}
  })();
}

/* ---------- Onglets ---------- */
function initOnglets() {
  const onglets = Array.from(document.querySelectorAll(".onglet"));
  const montrer = (page) => {
    if (!$(page)) page = "pageAffiche";
    document.querySelectorAll(".page").forEach((p) => { p.style.display = p.id === page ? "block" : "none"; });
    onglets.forEach((o) => { o.className = "onglet" + (o.getAttribute("data-page") === page ? " actif" : ""); });
    lsSet("afm_page", page);
  };
  onglets.forEach((o) => o.addEventListener("click", () => montrer(o.getAttribute("data-page"))));
  montrer(lsGet("afm_page", "pageAffiche"));
}

/* =====================================================================
 * ASSISTANT IA — le client décrit son affiche, le plugin remplit tout
 *  1) analyseur intégré (hors ligne, gratuit)
 *  2) IA Claude (optionnelle, avec la clé API du client)
 * ===================================================================== */
const norm = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
const MOTS_MODELES = [
  ["soiree", ["soiree", "concert", "fete", "party", "dj ", "anniversaire", "bal ", "night", "festival", "spectacle", "showcase", "boite de nuit", "maquis"]],
  ["culte", ["culte", "eglise", "priere", "croisade", "veillee", "messe", "gospel", "chretien", "mosquee", "ramadan", "pasteur", "evangel", "louange", "adoration", "seminaire biblique", "jubile"]],
  ["immo", ["maison", "villa", "terrain", "parcelle", "appartement", "immobili", "a vendre", "a louer", "location", "duplex", "studio a louer", "lotissement"]],
  ["chantier", ["btp", "chantier", "construction", "agregat", "sable", "gravier", "ciment", "beton", "genie civil", "travaux", "batiment", "carriere", "orbite"]],
  ["promo", ["promo", "reduction", "solde", "offre", "black friday", "remise", "destockage", "liquidation", "%"]],
  ["epure", ["elegant", "simple", "minimal", "sobre", "professionnel", "corporate", "conference", "formation", "atelier"]],
  ["produits", ["produit", "boutique", "collection", "nouveaute", "chaussure", "sac ", "sacs", "vetement", "parfum", "telephone", "accessoire", "cosmetique", "perruque", "meche", "montre", "article", "arrivage"]],
  ["moderne", ["startup", "digital", "application", "appli", "moderne", "tech", "agence", "webinaire", "lancement"]],
  ["photo", ["photo", "restaurant", "menu", "plat", "portrait"]]
];
const TITRES_DEFAUT = { produits: "NOUVEL ARRIVAGE", moderne: "LANCEMENT", soiree: "GRANDE SOIRÉE", culte: "CULTE SPÉCIAL", immo: "À VENDRE", chantier: "CONSTRUCTION & BTP", promo: "GRANDE PROMO", epure: "ÉVÉNEMENT", photo: "NOUVEAUTÉ", impact: "GRANDE ANNONCE" };
const COULEURS_MOTS = [[0, ["orange"]], [1, ["bleu"]], [2, ["vert"]], [3, ["rouge", "bordeaux"]], [4, ["noir", "dore", "or ", "luxe", "chic"]], [5, ["violet", "rose", "mauve"]]];
const VILLES = ["Ouagadougou", "Ouaga", "Bobo-Dioulasso", "Bobo", "Koudougou", "Ouahigouya", "Banfora", "Kaya", "Tenkodogo", "Fada N'Gourma", "Dédougou", "Ziniaré", "Koupéla", "Manga", "Abidjan", "Bamako", "Niamey", "Lomé", "Cotonou", "Dakar", "Accra"];
const JOURS = "lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche";
const MOIS = "janvier|fevrier|février|mars|avril|mai|juin|juillet|aout|août|septembre|octobre|novembre|decembre|décembre";

function analyserDemande(texte) {
  const t = String(texte || ""), n = " " + norm(t) + " ";
  const out = {};
  // Modèle
  let best = null, score = 0;
  for (const [m, mots] of MOTS_MODELES) { const s = mots.filter((w) => n.includes(w)).length; if (s > score) { score = s; best = m; } }
  out.modele = best || "impact";
  if (out.modele === "immo" && /\ba louer|location\b/.test(n)) out.titreDefaut = "À LOUER";
  if (out.modele === "chantier" && /agregat|sable|gravier/.test(n)) out.titreDefaut = "VENTE D'AGRÉGATS";
  // Format
  if (/story|statut|status|tiktok|reel/.test(n)) out.format = "story";
  else if (/facebook|instagram|carre|post\b|reseaux/.test(n)) out.format = "carre";
  else if (/banniere|paysage|youtube|ecran|television|tv\b|couverture/.test(n)) out.format = "paysage";
  else if (/\ba3\b|grand format/.test(n)) out.format = "a3";
  else if (/\ba5\b|flyer|prospectus/.test(n)) out.format = "a5";
  else if (/\ba4\b|imprim|papier/.test(n)) out.format = "a4";
  // Couleurs
  for (const [i, mots] of COULEURS_MOTS) if (mots.some((w) => n.includes(" " + w) || n.includes(w + " "))) { out.palette = i; break; }
  // Titre : texte entre guillemets, ou « titre : … »
  const q = t.match(/[«"“]\s*([^»"”]{2,60})\s*[»"”]/) || t.match(/titre\s*[:=]\s*([^\n.,;]{2,60})/i);
  if (q) out.titre = q[1].trim();
  const st = t.match(/(?:sous-titre|slogan|theme|thème)\s*[:=]\s*([^\n.;]{2,80})/i);
  if (st) out.sousTitre = st[1].trim();
  else { const sur = t.match(/\bsur (tous|toutes|tout|toute|l'ensemble de) [^,.;\n]{3,40}/i); if (sur) out.sousTitre = sur[0].charAt(0).toUpperCase() + sur[0].slice(1); }
  if (/anniversaire|enfant|bapteme|kermesse/.test(n)) out.police = "fun";
  else if (/mariage|noces|fiancailles|saint.valentin|dot\b/.test(n)) out.police = "script";
  else if (/luxe|elegant|chic|gala/.test(n)) out.police = "elegant";
  if (/anniversaire/.test(n)) out.titreDefaut = "JOYEUX ANNIVERSAIRE";
  else if (/mariage|noces/.test(n)) out.titreDefaut = "MARIAGE";
  else if (/ouverture|inauguration/.test(n)) out.titreDefaut = "GRANDE OUVERTURE";
  else if (/recrut|embauche/.test(n)) out.titreDefaut = "ON RECRUTE";
  // Badge : pourcentage, prix, gratuit
  const pc = t.match(/-?\s?\d{1,2}\s?%/);
  const prix = t.match(/(\d{1,3}(?:[ . ]?\d{3})*(?:[.,]\d+)?)\s?(f\s?cfa|fcfa|cfa|francs?|f\b|xof|€|euros?)/i);
  if (pc) out.badge = (pc[0].trim().startsWith("-") ? "" : "-") + pc[0].replace(/\s/g, "");
  else if (/entree (libre|gratuite)|acces (libre|gratuit)|gratuit pour tous|c'est gratuit/.test(n) || (/\bgratuit/.test(n) && !/(devis|livraison|conseil|estimation) gratuit/.test(n))) out.badge = "GRATUIT";
  else if (prix) out.badge = prix[1].replace(/[. ]/g, " ").trim() + " F";
  // Date + heure
  const morceaux = [];
  const d1 = t.match(new RegExp("((?:" + JOURS + ")\\s+)?(?:le\\s+)?(\\d{1,2}(?:er)?)\\s+(" + MOIS + ")(\\s+\\d{4})?", "i"));
  const d2 = t.match(/\b(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2,4}))?\b/);
  const jr = t.match(new RegExp("\\b(" + JOURS + ")\\b", "i"));
  if (d1) morceaux.push(d1[0].replace(/^le\s+/i, "").replace(/\s+/g, " ").trim());
  else if (d2 && !/^\d{2}$/.test(d2[0])) morceaux.push((/jusqu/.test(norm(t.slice(Math.max(0, d2.index - 12), d2.index))) ? "jusqu'au " : "") + d2[0]);
  else if (jr) morceaux.push(jr[1]);
  const h = t.match(/(?:^|\s)(?:a|à|des|dès|de|vers)\s+(\d{1,2})\s?h\s?(\d{2})?(?![\wÀ-ÿ])/i) || t.match(/(?:^|\s)(\d{1,2})h(\d{2})(?![\wÀ-ÿ])/i);
  if (h) morceaux.push("à " + h[1] + "h" + (h[2] || ""));
  // Lieu
  const ville = VILLES.find((v) => n.includes(" " + norm(v)));
  const KW = "(?:[ÉEée]glise|[Ss]alle|[Pp]alais|[Mm]aison des|[Ss]tade|[Hh][ôo]tel|[Cc]entre|[Pp]lace|[Ee]space|[Bb]outique|[Rr]estaurant|[Mm]aquis|[Ii]nstitut|[Ll]yc[ée]e|[ÉE]cole|[Cc]ath[ée]drale|[Pp]aroisse|[Tt]emple|[Mm]osqu[ée]e|[Cc]lub|[Bb]ar|[Mm]agasin|[Ss]upermarch[ée])";
  const NOM = "[A-ZÉÈ][\\wÀ-ÿ'’-]*(?:\\s+(?:de la|de l'|de|du|des|la|le|d'|et)?\\s*[A-ZÉÈ0-9][\\wÀ-ÿ'’-]*){0,4}";
  const STOP = /^(whatsapp|tel|tél|contact|prix|entree|entrée|appel|promo|format|couleur|facebook|instagram)/i;
  let lieu = null;
  for (const re of [new RegExp("(?:^|[\\s,])(?:au|à la|a la|à l'|chez|lieu\\s*:)\\s+((?:" + KW + "\\s+)?" + NOM + ")"), new RegExp("(?:^|[\\s,])(" + KW + "\\s+" + NOM + ")")]) {
    const mm = t.match(re);
    if (mm && !STOP.test(mm[1])) { lieu = [mm[0], mm[1].charAt(0).toUpperCase() + mm[1].slice(1)]; break; }
  }
  if (lieu) morceaux.push(lieu[1].trim());
  if (ville && !(lieu && norm(lieu[1]).includes(norm(ville)))) morceaux.push(ville === "Ouaga" ? "Ouagadougou" : ville === "Bobo" ? "Bobo-Dioulasso" : ville);
  if (morceaux.length) out.dateLieu = morceaux.map((m, i) => (i === 0 ? m.charAt(0).toUpperCase() + m.slice(1) : m)).join(" · ");
  // Contact (téléphone)
  const tel = t.match(/(\+?226)?[\s.]?(\d{2})[\s.]?(\d{2})[\s.]?(\d{2})[\s.]?(\d{2})\b/);
  if (tel) {
    const num = "+226 " + [tel[2], tel[3], tel[4], tel[5]].join(" ");
    out.contact = (/whatsapp|whats app|wa\b/.test(n) ? "WhatsApp : " : "Tél : ") + num;
  }
  // Détails : morceaux de phrase descriptifs qui ne répètent pas les infos déjà placées
  const deja = [out.titre, out.sousTitre, lieu && lieu[1]].filter(Boolean).map(norm);
  const morceauxTxt = t.split(/[.!?\n;,]+/).map((s) => s.trim()).filter(Boolean)
    .map((s) => s.replace(/^(je veux|j'aimerais|j'ai besoin d'|j'ai besoin de|fais(-moi)?|fait(-moi)?|cree(-moi)?|crée(-moi)?|mets|met|il faut)\s+/i, "")
                 .replace(/^(une |l'|la )?affiche\s+(pour|de|d'|sur)?\s*/i, "").replace(/^(une |un )?(flyer|visuel|poster)\s+(pour|de)?\s*/i, "").trim())
    .filter((s) => s.length > 6)
    .filter((s) => !/\d{2}[\s.]?\d{2}[\s.]?\d{2}[\s.]?\d{2}/.test(s) && !/%/.test(s))
    .filter((s) => !/(f\s?cfa|fcfa|\bcfa\b|francs?\b|\bprix\b|\bentree\b|entrée)/i.test(s))
    .filter((s) => !/(couleur|format|statut|status|facebook|instagram|whatsapp|\btel\b|tél|contact|appelez|appeler|en (rouge|bleu|vert|noir|orange|violet|rose))/i.test(s))
    .filter((s) => !new RegExp("^((le|du|au)\\s+)?(" + JOURS + ")\\b", "i").test(s) && !new RegExp("\\d{1,2}\\s+(" + MOIS + ")", "i").test(s))
    .filter((s) => !deja.some((d) => d && norm(s).includes(d)))
    .filter((s) => !VILLES.some((v) => norm(s) === norm(v)));
  if (morceauxTxt.length) {
    let d = morceauxTxt.slice(0, 3).join(" · ");
    d = d.charAt(0).toUpperCase() + d.slice(1);
    out.details = d.slice(0, 150);
  }
  if (!out.titre) out.titre = out.titreDefaut || TITRES_DEFAUT[out.modele];
  return out;
}

async function demanderClaude(texte, cle) {
  const consigne = "Tu es l'assistant d'Affiche Minute, un plugin Photoshop qui crée des affiches au Burkina Faso. " +
    "À partir de la demande du client, réponds UNIQUEMENT avec un objet JSON valide, sans texte autour, avec ces clés : " +
    "modele (impact|photo|epure|promo|soiree|culte|immo|chantier|produits|moderne), police (moderne|impact|elegant|fun|eglise|script|tech), format (a4|a5|a3|carre|story|paysage), " +
    "palette (0=orange,1=bleu,2=vert,3=rouge,4=noir et or,5=violet), titre (2 à 4 mots, accrocheur), sousTitre (court), " +
    "details (1 phrase, 140 caractères max), dateLieu (ex. « Samedi 15 novembre · 20h · Ouagadougou »), badge (ex. « -30% », « GRATUIT », « 5 000 F »), " +
    "contact (téléphone / WhatsApp). Écris en français. Laisse une chaîne vide pour ce qui est inconnu ; n'invente ni numéro ni date.";
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": cle, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" },
    body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 700, system: consigne, messages: [{ role: "user", content: texte }] })
  });
  const j = await r.json();
  if (!r.ok) throw new Error((j && j.error && j.error.message) || ("erreur " + r.status));
  const brut = (j.content || []).map((c) => c.text || "").join("");
  const m = brut.match(/\{[\s\S]*\}/);
  if (!m) throw new Error("réponse illisible");
  return JSON.parse(m[0]);
}

function appliquerAssistant(o) {
  const champs = [["titre", "titre"], ["sousTitre", "sousTitre"], ["details", "details"], ["dateLieu", "dateLieu"], ["badge", "badge"], ["contact", "contact"]];
  const remplis = [];
  for (const [cle, id] of champs) { const v = (o[cle] || "").toString().trim(); if (v) { $(id).value = v; remplis.push(cle); } }
  if (o.modele && MODELES[o.modele]) { choisirModele(o.modele); remplis.push("modèle"); }
  if (o.police && STYLES_POLICES[o.police]) { $("stylePolice").value = o.police; remplis.push("polices"); } else { $("stylePolice").value = "auto"; }
  setTimeout(majNotePolice, 0);
  if (o.format && FORMATS[o.format]) { $("format").value = o.format; remplis.push("format"); }
  const p = parseInt(o.palette, 10);
  if (!isNaN(p) && PALETTES[p]) { choisirPalette(p); remplis.push("couleurs"); }
  return remplis;
}

async function lancerAssistant(generer_apres) {
  const texte = ($("iaTexte").value || "").trim();
  const st = $("iaStatut");
  if (texte.length < 8) { st.textContent = "Décris ton affiche en une ou deux phrases (événement, date, lieu, prix, contact…)."; st.className = "msg erreur"; return; }
  let res, source = "assistant intégré";
  const cle = (lsGet("afm_cle_ia", "") || "").trim();
  if (cle) {
    st.textContent = "L'IA réfléchit…"; st.className = "msg";
    try { res = await demanderClaude(texte, cle); source = "IA Claude"; }
    catch (e) { res = null; st.textContent = "IA indisponible (" + e.message + ") : j'utilise l'assistant intégré."; }
  }
  if (!res) res = analyserDemande(texte);
  const remplis = appliquerAssistant(res);
  st.textContent = "✓ Rempli par l'" + source + " : " + remplis.join(", ") + ". Vérifie, ajoute ta photo et ton logo" + (generer_apres ? "… génération en cours." : ", puis clique sur « Générer l'affiche ».");
  st.className = "msg ok";
  if (generer_apres) await generer();
}

function initAssistant() {
  $("iaRemplir").addEventListener("click", () => lancerAssistant(false));
  $("iaGenerer").addEventListener("click", () => lancerAssistant(true));
  $("iaReglages").addEventListener("click", () => { const z = $("iaZoneCle"); z.style.display = z.style.display === "none" ? "block" : "none"; });
  $("iaCle").value = lsGet("afm_cle_ia", "");
  $("iaEnregistrer").addEventListener("click", () => {
    const v = ($("iaCle").value || "").trim();
    if (v) lsSet("afm_cle_ia", v); else lsDel("afm_cle_ia");
    $("iaEtat").textContent = v ? "Clé enregistrée : l'IA Claude sera utilisée." : "Pas de clé : l'assistant intégré (gratuit) est utilisé.";
  });
  $("iaEtat").textContent = lsGet("afm_cle_ia") ? "IA Claude activée." : "Assistant intégré (gratuit, hors ligne).";
  document.querySelectorAll(".exemple").forEach((e) => e.addEventListener("click", () => { $("iaTexte").value = e.getAttribute("data-t"); }));
}

function init() {
  remplirFormats();
  remplirPalettes();
  remplirPolices();
  document.querySelectorAll(".tuile").forEach((t) => t.addEventListener("click", () => choisirModele(t.getAttribute("data-m"))));
  ["cFond", "cAccent", "cTexte", "cSombre"].forEach((id) => $(id).addEventListener("input", majPastilles));
  $("btnPhoto").addEventListener("click", () => choisirFichier("photo"));
  $("btnLogo").addEventListener("click", () => choisirFichier("logo"));
  $("xPhoto").addEventListener("click", () => effacer("photo"));
  $("xLogo").addEventListener("click", () => effacer("logo"));
  $("btnGenerer").addEventListener("click", generer);
  $("btnProduits").addEventListener("click", choisirProduits);
  $("xProduits").addEventListener("click", () => { state.produits = []; afficherProduits(); });
  $("stylePolice").addEventListener("change", majNotePolice);
  $("lienPolices").addEventListener("click", async () => { try { await uxp.shell.openExternal("https://fonts.google.com/?query=Montserrat", "Polices gratuites Google Fonts"); } catch (e) {} });
  $("btnLicence").addEventListener("click", () => {
    const z = $("zoneCle");
    z.style.display = z.style.display === "none" ? "block" : "none";
  });
  $("btnActiver").addEventListener("click", activer);
  $("btnAcheter").addEventListener("click", acheter);
  majLicence();
  restaurer();
  initOutils();
  initTexte3D();
  initTitresPrets();
  initModeles();
  initOnglets();
  initAssistant();
  initAchat();
}

init();
